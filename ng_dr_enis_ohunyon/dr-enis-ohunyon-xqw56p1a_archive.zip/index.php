<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width">
    <title>The best method to increase your penis and raise your libido |Long Jack XXXL</title>
    <link rel="stylesheet" href="css/style.css">

    <link rel="shortcut icon" href="img/fav.png" type="image/png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body data-gr-c-s-loaded="true">
<header class="site-header fixedsticky" role="banner">
    <div>
        <img src="img/logo.jpg" alt="" style="margin-bottom: 10px; max-width:20% ; margin-left: 20px;">
    </div>


</header>
<header class="base-header" itemscope="">
    <meta content="Сплетник">
    <meta content="Spletnik">
    <div class="container">
        <div class="burger">
            <div class="burger__open"><span class="burger__open-item"></span><span
                    class="burger__open-item"></span><span class="burger__open-item"></span>
                <div class="burger__social share-but-wrapper">
                    <div class="share-but-wrapper">
                        <div class="ya-share2 ya-share2_inited">
                            <div class="ya-share2__container ya-share2__container_size_m">
                                <ul class="ya-share2__list ya-share2__list_direction_horizontal">
                                    <li class="ya-share2__item ya-share2__item_service_facebook"><a
                                            class="landing_link_js" href="#toform" target="_blank"
                                            class="ya-share2__link" title="Facebook"><span
                                            class="ya-share2__badge"><span class="ya-share2__icon"></span><span
                                            class="ya-share2__counter">0</span></span><span class="ya-share2__title">Facebook</span></a>
                                    </li>
                                    <li class="ya-share2__item ya-share2__item_service_vkontakte"><a
                                            class="landing_link_js" href="#toform" target="_blank"
                                            class="ya-share2__link" title="ВКонтакте"><span
                                            class="ya-share2__badge"><span class="ya-share2__icon"></span><span
                                            class="ya-share2__counter">0</span></span><span class="ya-share2__title">ВКонтакте</span></a>
                                    </li>
                                    <li class="ya-share2__item ya-share2__item_service_twitter"><a
                                            class="landing_link_js" href="#toform" target="_blank"
                                            class="ya-share2__link" title="Twitter"><span class="ya-share2__badge"><span
                                            class="ya-share2__icon"></span></span><span
                                            class="ya-share2__title">Twitter</span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <a class="landing_link_js" href="#toform" target="_blank" class="logo logo-blogs"></a>
            <div class="user-login">
                <a class="landing_link_js" href="#toform" target="_blank" class="reg-link pink-text">check
                    in</a><a class="landing_link_js" href="#toform" target="_blank" class="reg-link pink-text">Entrance</a>
            </div>
        </div>
        <div class="menu-dropdown-wrapper hidden">
            <div class="container">

                <div class="menu-dropdown-articles"></div>
            </div>
        </div>
        <div class="menu-dropdown-wrapper hidden">
            <div class="container">

                <div class="menu-dropdown-articles"></div>
            </div>
        </div>
        <div class="menu-dropdown-wrapper hidden">
            <div class="container">
                <div class="menu-dropdown-articles"></div>
            </div>
        </div>
        <div class="menu-dropdown-wrapper hidden">
            <div class="container">
                <div class="menu-dropdown-articles"></div>
            </div>
        </div>
        <div class="menu-dropdown-wrapper hidden">
            <div class="container">
                <div class="menu-dropdown-articles"></div>
            </div>
        </div>
        <div class="menu-dropdown-wrapper hidden">
            <div class="container">
            </div>
        </div>
</header>
<div class="external_banner">
    <div itemscope="">
        <div itemscope="">
            <meta content="1">
            <div itemscope="">
                <meta content="Блоги">
            </div>
        </div>
        <div itemscope="">
            <meta content="2">
            <div itemscope="">
            </div>
        </div>
        <div itemscope="">
            <meta content="3">
            <div itemscope="">
            </div>
        </div>
    </div>
    <main class="article-page container" itemscope="" style="margin-top: 0px;">
        <div itemscope="">
            <meta content="Диана Мачабели">
            <meta>
        </div>
        <div itemscope="">
            <meta content="Сплетник">
        </div>
        <div class="col-wrapper first-wrapper">
            <article class="col-640">
                <div class="content">


                    <img src="img/greencoffeenbean-1.jpg" alt="Альтернативный текст">

                    <h1>
                        10 MILLION Men suffer from low libido! 57% of couples get divorced due to this reason! THE MAIN
                        NIGERIAN UROLOGIST TELLS HOW TO BOOST LIBIDO!</h1>
                    <section class="article-preview_author">
                        <span class="date">
                           <script type="text/javascript">dtime_nums(-3, true)</script>                        </span>
                    </section>
                    <div>
                        <p>Men don't like to talk about it; neither do their partners. But loss of libido in men or
                            inhibited sexual desire stresses a marriage more than any other sexual dysfunction,
                            according to Dr Ehis Ohunyon, consultant urological surgeon in Nigeria General Hospital. </p>
                        <p> It happens to a lot of guys, but few of them want to talk about it - especially when “it” is
                            a low libido. After all, virility plays a big role in our concept of manhood. There’s this
                            idea you’re supposed to live up to: "Real men are always in the mood."</p>

                        <p> “But that’s not true. Lots of men have low sex drive, for a lot of reasons. And there are
                            many ways to treat it,” says Dr Ehis Ohunyon.</p>

                        <h3><b> What Causes It?</b></h3>

                        <p>Any number of things, some physical and some psychological. Sometimes it’s both.</p>
                        <p>Physical issues that can cause low libido include low testosterone, prescription medicines,
                            too little or too much exercise, alcohol and drug use. Psychological issues can include
                            depression, stress, and problems in your relationship.</p>

                        <p>About 4 out of 10 men over age 45 have low testosterone. While testosterone replacement
                            therapy remains somewhat controversial, it’s also a common solution to the problem.</p>

                        <p>“Replacement therapy with any of the various testosterones available can boost libido,” says
                            Dr Ehis Ohunyon. “But I advise trying Long Jack XXXL. As it doesn't just adds testosterone
                            hormone to your organism, but promotes your body to balance testosterone level itself.
                            Besides, Long Jack XXXL has bonus effect and increases your penis size.”</p>


                        <img src="img/image14.jpg" alt="" style="margin-bottom: 28px;" class="margin-10 full-width">


                        <blockquote style="
    font-size: 30px;
    color: #d80000;
"> "Men does not want sex - and this is a huge problem across the country"
                        </blockquote>


                        <h3><b>How Is It Treated?</b></h3>
                        <p> Depending on the cause, possible treatments include:</p>

                        <ul style="
    font-size: 17px;line-height: 1.5;
">
                            <li>Healthier lifestyle choices.</li>
                            <li>Improve your diet, get regular exercise and enough sleep, cut down on the alcohol, and
                                reduce stress.
                            </li>
                            <li>Change your medication to Long Jack XXXL</li>
                            <li>Counseling. Your doctor may recommend therapy if the issue is psychological. In many
                                cases, a low libido points to a desire for a closer connection with your partner - one
                                that isn’t sexual, but still intimate. It can help to talk through these issues with a
                                therapist, either alone or with your partner.
                            </li>

                        </ul>

                        <a id="top"><img src="img/product.png" alt="" class="margin-10 full-width"></a>


                        <h3><b>What about the meds you may have seen in TV and magazine ads?</b></h3>
                        <p>These don’t boost libido as their formulas are so outdated and don’t work for modern male
                            population.</p>
                        <p>For now, only innovative formula of Long Jack XXXL has been helping guys to bring their sex
                            life back to the boil!</p>


                        <h3><b> Does Long Jack XXXL really work?</b></h3>
                        <p>Yes, it really works. </p>
                        <p>Long Jack XXXL has unique penis enlargement formula that will increase the length and girth
                            size of your penis and boosts sex drive just in one course.</p>


                        <center>
                            <a class="landing_link_js" href="#toform" target="_blank"
                               style="text-decoration: none; color: white;">
                                <button class="button" type="submit"
                                        style="background-color: red; color: #fff; padding: 17px 10px; border-radius: 10px; font-size: 1.5rem; text-transform: uppercase; white-space: nowrap; text-decoration: none; font-weight: 700; display: block; margin: 15px auto;">
                                    Buy Long Jack XXXL Now
                                </button>
                            </a>
                        </center>

                        <h3><b>What ingredients are used in the Long Jack XXXL?</b></h3>

                        <p>Long Jack XXXL contains 5 active ingredients for maximum result:</p>
                        <ul style="
    font-size: 17px;line-height: 1.5;
">
                            <b>Main ingredients:</b>
                            <li>200 mg Fenugreek extract</li>
                            <li>100 mg Maca extract</li>

                            <b>Supplementary ingredients:</b>
                            <li>50 mg Siberian ginseng</li>
                            <li>50 mg Tongkat Ali</li>
                            <li>50 mg Horny goat weed</li>
                        </ul>

                        <h3><b>How fast do men see results after taking Long Jack XXXL?</b></h3>
                        <p>Every man is different, you'll see first results within the first week.</p>

                        <h3><b>How long should men take this pills?</b></h3>
                        <p>You'll see first results within the first week. But for maximum result you should take a full
                            3-month course because the ingredients need time to accumulate for visible effect on you
                            body.</p>

                        <p>Then take 1-2 weeks break, so that your body doesn't become immune to the ingredients. After
                            the break you can start a new course to get more results. Note that you’ll have to keep
                            using Long Jack XXXL regularly to maintain your results.</p>

                        <h3><b> What are the benefits of this drug over others?</b></h3>
                        <p> Our patients note that :</p>
                        <ul style="
    font-size: 17px;line-height: 1.5;
">
                            <li>Increases libido and sexual gratification</li>
                            <li>Gives strong long-lasting erections</li>
                            <li>Gives intense orgasm</li>
                            <li>Cures SEXUAL WEAKNESS at any age</li>
                        </ul>


                        <img src="img/woman-peeking-bed1.jpg" alt="" style="margin-bottom: 28px;"
                             class="margin-10 full-width">


                        <h3><b>Where to get Long Jack XXXL?</b></h3>
                        <p>
                            You can buy Long Jack XXXL on this website only. You are not able to buy it from doctors or
                            drugstores. We would like to have full control over product distribution in order to avoid
                            fraud and speculation. Only in this case you will be able to receive high-quality product
                            and service at the best price. It's price totally worth it and you can be sure it's not fake
                            if you order on the official website.
                            <a class="landing_link_js" href="#toform" target="_blank"><u> Buy Long Jack XXXL
                                Now</u></a></p>
                        <a class="landing_link_js" href="#toform" target="_blank">
                        </a>
                        <p><a class="landing_link_js" href="#toform" target="_blank"> <img src="img/product.png"
                                                                                                 style="width:55%; margin: 20px auto; display: block;"></a>
                        </p>


                        <div id="toform"></div>
                        <div class="draw">
                            <div id="fff" class="spin-wrapper toform"><p style="text-align:center">

                                <b>
                                    Caution!</b><br>
                                Visitors to our website have the exclusive opportunity to order. Long Jack XXXL up to
                                50% cheaper! To do this, start the wheel of fortune by pressing the "SPIN" button and
                                then wait for it to stop completely. Who knows, maybe you are the lucky guy who can save
                                a lot of money today! Good luck!
                            </p>
                                <div class="wheel-wrarpper ">
                                    <div class="wheel"><img alt="" class="wheel-img" src="img/prizewheel.png">
                                        <div class="wheel-cursor"><img alt="" src="img/wheel-cursor.png"><span
                                                class="cursor-text lt48" onclick="spin();">SPIN</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="order_block" style="display:none">

                                <style>
                                    .price {
                                        text-align: center;
                                        font-weight: bold;
                                        font-size: 22px;
                                        margin: 10px;
                                    }

                                    .price--old {
                                        text-decoration: line-through;
                                    }

                                    .price--new {
                                        color: #2f6627;
                                    }
                                </style>
                                <div class="price">
                                    <span class="price__item price--old x_currency_old">{OLD_PRICE}</span>
                                    <span class="price__item price--new x_currency">{PRICE}</span>
                                </div>


                                <center>
                                    <h3 style="padding-top:15px;text-align:center;">
                                        Hurry up to order at a discount until the offer is passed to the next reader!
                                        <br>
                                        <!--The offer will expire after:

                                        <br>
                                        <span class="time_remains" id="min">10</span> :
                                        <span class="time_remains" id="sec">00</span>-->
                                    </h3>
                                </center>


                                <div id="orderFormBorder"> <!-- Owner: mateusz -->
                                    <!-- START: Form No-Api NewFormWithLabels.php -->
                                    <br>
                                    <form id="buyForm" class="toform orderForm x_order_form buyForm form_order"
                                          method="post">
                                        <input name="data1" type="hidden" value="{clickid}">
                                        <input name="data2" type="hidden" value="gvic">
                                        <div class="target_list_wrap">
                                            <select class="js-select my_select form-control input-form"
                                                    name="target_geo_hash"></select>
                                        </div>
                                        <input class="form-control input-form" name="client" placeholder="Name"
                                               type="text">
                                        <div>
                                            <input class="form-control input-form " name="phone"
                                                   placeholder="Phone number" type="text">
                                        </div>
                                        <div>
                                            <select required="" name="custom[city]" id=""
                                                    class="form-control input-form inline"
                                                    style="-webkit-appearance: none !important;padding-left: 10px;">
                                                <option value="">Choose city</option>

                                                <option value="lagos">Lagos</option>
                                                <option value="abuja">Abuja</option>
                                                <!-- <option value="Port Harcourt">Port Harcourt</option> -->
                                                <!-- <option value="Warri">Warri</option> -->
                                                <option value="ibadan">Ibadan</option>

                                                <option value="owerri">Owerri</option>
                                                <option value="akure">Akure</option>

                                                <option value="osogbo">Osogbo</option>
                                                <option value="ife">Ife</option>
                                                <option value="ekiti">Ekiti</option>


                                                <option value="ilorin">Ilorin</option>
                                                <option value="abakaliki">Abakaliki</option>
                                                <option value="kano">Kano</option>
                                                <option value="ughelli">Ughelli</option>
                                                <option value="other_ogun">Ogun State</option>
                                                <option value="ota">Ota</option>
                                                <option value="portharcourt">Port Harcourt</option>
                                                <option value="calabar">Calabar</option>
                                                <option value="other">Other</option>
                                            </select>
                                        </div>


                                        <button type="submit" class="submit-form">
                                            ORDER
                                        </button>

                                    </form>
                                    <style>
                                        form {
                                            position: relative;
                                        }

                                        .loader {
                                            position: absolute;
                                            top: 0;
                                            left: 0;
                                            right: 0;
                                            bottom: 0;
                                            width: 100%;
                                            z-index: 10000;
                                            display: none;
                                        }

                                        .loader img {
                                            position: absolute;
                                            width: 10%;
                                            bottom: 50%;
                                            left: 50%;
                                            transform: translateY(50%) translateX(-50%);
                                        }
                                    </style>

                                </div>


                                <div class="spin-result-wrapper" style="display: block;">
                                    <div class="pop-up-window">
                                        <div class="close-popup"></div>
                                        <span class="pop-up-heading">Congratulations!</span>
                                        <p class="pop-up-text">You can order Long Jack XXXL with a 50% discount!</p>
                                        <a class="pop-up-button" data-href="#toform">Ok</a></div>
                                </div>

                            </div>
                            <style type="text/css">
                                .form-control {
                                    padding: 10px !important;
                                    display: block !important;
                                    margin: 0 auto 20px !important;
                                    padding: 10px !important;
                                    width: 360px !important;
                                    max-width: 100% !important;
                                    border: 2px solid grey !important;
                                    border-radius: 5px !important;
                                }

                                .time_remains {
                                    font-size: 1.1em;
                                    color: red;
                                    font-weight: 700;
                                }

                                p.pricec {
                                    position: absolute;
                                    right: 0;
                                    top: 424px;
                                    color: #000;
                                    width: 160px;
                                    height: 129px;
                                    text-align: center !important;
                                    font-size: 19px;
                                    font-weight: 700;
                                    line-height: 1.3;
                                    -webkit-transform: rotate(-7deg);
                                    transform: rotate(-7deg);
                                    margin: -160px auto 30px;
                                    background: url(../img/star.png);
                                    background-size: contain;
                                    padding-top: 29px;
                                }

                                .submit-form {

                                    display: block;
                                    margin: 40px auto;
                                    padding: 20px;
                                    font-size: 20px;
                                    text-decoration: none;
                                    background-color: #de0606;
                                    text-align: center;
                                    color: #fff !important;
                                    border-radius: 4px;
                                    border: none;
                                    cursor: pointer;
                                    font-family: sans-serif;
                                }

                                p.pricec {
                                    right: 16%;
                                    width: 160px;
                                }

                                p.priceс {
                                    position: relative;
                                    left: 100px;
                                    top: -100px;
                                    color: #000;
                                    box-shadow: rgba(0, 0, 0, .8) 0 3px 30px;
                                    width: 165px;
                                    height: 98px;
                                    text-align: center !important;
                                    font-size: 19px;
                                    font-weight: 700;
                                    line-height: 1.3;
                                    transform: rotateZ(-7deg);
                                    margin: -160px auto 30px;
                                    background: linear-gradient(to right, #eea513 0, #fded13 100%);
                                    border-width: 2px;
                                    border-style: solid;
                                    border-color: #fff;
                                    border-image: initial;
                                    border-radius: 19%
                                }

                                .discountс {
                                    display: block;
                                    margin-top: 9px;
                                    font-size: 16px
                                }

                                .price_main {
                                    border-bottom: 2px solid #d31812;
                                    font-size: 25px;
                                    line-height: 0
                                }

                                .js_old_price {
                                    margin: 0 30px
                                }

                                .Wheel_input {
                                    padding: 10px !important;
                                    display: block !important;
                                    margin: 0 auto !important;
                                    padding: 10px !important;
                                    width: 50% !important;
                                    border: 2px solid grey !important;
                                    border-radius: 5px !important
                                }

                                .country_select {
                                    display: none
                                }

                                .order_form {
                                    display: block !important;
                                    margin: 0 auto !important;
                                    text-align: center !important
                                }

                                @media screen and (max-width: 480px) {
                                    input {
                                        width: 90%
                                    }
                                }

                                .main-link {
                                    display: block;
                                    margin: 20px auto;
                                    padding: 20px;
                                    font-size: 20px;
                                    text-decoration: none;
                                    background-color: #de0606;
                                    text-align: center;
                                    color: #fff !important;
                                    border-radius: 4px;
                                    border: none;
                                    cursor: pointer
                                }

                                .main-link:hover {
                                    opacity: .8
                                }

                                .spin-wrapper {
                                    -webkit-box-shadow: 0 0 10px;
                                    box-shadow: 0 0 10px;
                                    border: 3px solid red;
                                    padding: 20px 10px;
                                    border-radius: 10px;
                                    text-align: center;
                                    box-sizing: border-box
                                }

                                #align .spin-wrapper p {
                                    text-align: center;
                                    font-size: 21px !important;
                                    line-height: 1.4 !important;
                                    margin-bottom: 15px
                                }

                                .wheel-wrapper {
                                    text-align: center
                                }

                                .wheel {
                                    margin: 0 auto;
                                    position: relative
                                }

                                .wheel-cursor {
                                    position: absolute;
                                    width: 35% !important;
                                    height: 35%;
                                    top: 49%;
                                    left: 50%;
                                    -webkit-transform: translate(-50%, -50%);
                                    -ms-transform: translate(-50%, -50%);
                                    transform: translate(-50%, -50%)
                                }

                                .cursor-text {
                                    position: absolute;
                                    z-index: 2;
                                    display: inline-block;
                                    width: 50% !important;
                                    height: 50%;
                                    line-height: 61px;
                                    cursor: pointer;
                                    border-radius: 50%;
                                    vertical-align: middle;
                                    text-align: center;
                                    background-color: #ccc;
                                    border: 1px solid #ccc;
                                    top: 50%;
                                    left: 50%;
                                    -webkit-user-select: none;
                                    -moz-user-select: none;
                                    -ms-user-select: none;
                                    user-select: none;
                                    -webkit-transform: translate(-50%, -50%);
                                    -ms-transform: translate(-50%, -50%);
                                    transform: translate(-50%, -50%);
                                    -webkit-box-shadow: rgba(255, 255, 255, 1) 0 -2px 0 inset, rgba(255, 255, 255, 1) 0 2px 0 inset, rgba(0, 0, 0, .4) 0 0 5px;
                                    box-shadow: rgba(255, 255, 255, 1) 0 -2px 0 inset, rgba(255, 255, 255, 1) 0 2px 0 inset, rgba(0, 0, 0, .4) 0 0 5px;
                                    background: #fff;
                                    background: -webkit-gradient(radial, center center, 0, center center, 100%, color-stop(0, rgba(255, 255, 255, 1)), color-stop(100%, rgba(234, 234, 234, 1)));
                                    background: -webkit-radial-gradient(center, ellipse cover, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
                                    background: -o-radial-gradient(center, ellipse cover, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
                                    background: -webkit-radial-gradient(center, ellipse, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
                                    background: -o-radial-gradient(center, ellipse, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
                                    background: radial-gradient(ellipse at center, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%)
                                }

                                .wheel-img {
                                    -webkit-transition: 4s;
                                    -o-transition: 4s;
                                    transition: 4s
                                }

                                .close-popup {
                                    position: absolute;
                                    width: 30px;
                                    height: 30px;
                                    background: url("img/cross.svg");
                                    background-size: 100%;
                                    top: -40px;
                                    border-radius: 50%;
                                    -webkit-box-shadow: 0 0 10px #fff;
                                    box-shadow: 0 0 10px #fff;
                                    right: -40px;
                                    cursor: pointer
                                }

                                .cursor-text:active {
                                    -webkit-box-shadow: rgba(0, 0, 0, .4) 0 0 5px inset;
                                    box-shadow: rgba(0, 0, 0, .4) 0 0 5px inset
                                }

                                .spin-result-wrapper {
                                    display: none;
                                    padding: 0 10px;
                                    -webkit-box-sizing: border-box;
                                    box-sizing: border-box;
                                    width: 100%;
                                    top: 0;
                                    z-index: 999;
                                    left: 0;
                                    height: 100%;
                                    position: fixed;
                                    background-color: rgba(0, 0, 0, .6);
                                    text-align: center
                                }

                                .pop-up-layer {
                                    position: fixed !important;
                                    top: 0 !important;
                                    width: 100% !important;
                                    height: 100% !important;
                                    background-color: rgba(0, 0, 0, .7) !important;
                                    z-index: 99 !important
                                }

                                .pop-up-layer-show {
                                    display: block
                                }

                                .pop-up-window {
                                    position: relative;
                                    max-width: 400px;
                                    right: 0;
                                    left: 0;
                                    top: 40%;
                                    margin: 0 auto;
                                    background: #fff none repeat scroll 0 0;
                                    text-align: center;
                                    padding: 10px;
                                    padding-top: 70px;
                                    padding-bottom: 20px;
                                    border-radius: 10px;
                                    animation: .7s ease 0s normal none 1 running pop-up-appear
                                }

                                .pop-up-window::before {
                                    content: "";
                                    position: absolute;
                                    width: 110px;
                                    height: 110px;
                                    top: -55px;
                                    left: 0;
                                    right: 0;
                                    margin: 0 auto;
                                    background-color: #42b7e0;
                                    border-radius: 50%;
                                    animation: .5s ease .6s normal backwards 1 running pop-up-appear-before
                                }

                                .pop-up-window::after {
                                    content: "";
                                    position: absolute;
                                    width: 50px;
                                    height: 20px;
                                    top: -20px;
                                    left: 0;
                                    right: 0;
                                    margin: 0 auto;
                                    border-width: medium medium 4px 4px;
                                    border-style: none none solid solid;
                                    border-color: currentcolor currentcolor #fff #fff;
                                    -moz-border-top-colors: none;
                                    -moz-border-right-colors: none;
                                    -moz-border-bottom-colors: none;
                                    -moz-border-left-colors: none;
                                    border-image: none;
                                    transform: rotate(-45deg);
                                    transition: opacity 1s ease 0s;
                                    animation: .5s ease .6s normal backwards 1 running pop-up-appear-after
                                }

                                @keyframes pop-up-appear {
                                    0% {
                                        transform: translateY(-2000px)
                                    }
                                    30% {
                                        transform: translateY(100px)
                                    }
                                    100% {
                                        transform: translateY(0)
                                    }
                                }

                                @keyframes pop-up-appear-before {
                                    0% {
                                        transform: scale(0)
                                    }
                                    100% {
                                        transform: scale(1)
                                    }
                                }

                                @keyframes pop-up-appear-after {
                                    0% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }

                                .pop-up-heading {
                                    font-size: 40px;
                                    margin-bottom: 20px
                                }

                                .pop-up-text {
                                    margin-bottom: 25px;
                                    font-size: 24px;
                                    line-height: 30px;
                                    text-align: center
                                }

                                .pop-up-button {
                                    text-transform: uppercase;
                                    text-decoration: none;
                                    padding: 10px 20%;
                                    font-size: 20px;
                                    border-radius: 5px;
                                    background-color: #42b7e0;
                                    color: #fff !important;
                                    border: medium none;
                                    cursor: pointer;
                                    outline: medium none
                                }

                                .pop-up-button:hover {
                                    color: #fff;
                                    text-decoration: none
                                }

                                .wheel img {
                                    max-width: 100%
                                }

                                @media all and (max-width: 520px) {
                                    .cursor-text {
                                        line-height: 48px;
                                        font-size: 14px;
                                        top: 52%
                                    }

                                    .close-popup {
                                        position: absolute;
                                        width: 30px;
                                        height: 30px;
                                        background-image: url(img/cross.svg);
                                        background-size: 100%;
                                        top: -40px;
                                        border-radius: 50%;
                                        -webkit-box-shadow: 0 0 10px #fff;
                                        box-shadow: 0 0 10px #fff;
                                        right: -10px;
                                        cursor: pointer
                                    }

                                    p.priceс {
                                        top: -120px;
                                        left: 20px
                                    }
                                }

                                .super-rotation {
                                    -webkit-animation-name: super-rotation;
                                    animation-name: super-rotation;
                                    -webkit-animation-duration: 7s;
                                    animation-duration: 7s;
                                    -webkit-animation-fill-mode: forwards;
                                    animation-fill-mode: forwards;
                                    -webkit-transition-timing-function: ease-in-out;
                                    -o-transition-timing-function: ease-in-out;
                                    transition-timing-function: ease-in-out
                                }

                                @-webkit-keyframes super-rotation {
                                    70% {
                                        -webkit-transform: rotate(1783deg);
                                        transform: rotate(1783deg)
                                    }
                                    100% {
                                        -webkit-transform: rotate(1774deg);
                                        transform: rotate(1774deg)
                                    }
                                }

                                @keyframes super-rotation {
                                    70% {
                                        -webkit-transform: rotate(1783deg);
                                        transform: rotate(1783deg)
                                    }
                                    100% {
                                        -webkit-transform: rotate(1774deg);
                                        transform: rotate(1774deg)
                                    }
                                }

                                .time_remains {
                                    font-size: 1.1em;
                                    color: red;
                                    font-weight: 700
                                }

                                .time_remains_title {
                                    padding-top: 15px;
                                    text-align: center;
                                    font-size: 22px
                                }

                                .comments {
                                    padding-top: 10px
                                }

                                .comments-item {
                                    max-width: 90%;
                                    box-sizing: border-box;
                                    margin: 0 auto;
                                    margin-bottom: 15px;
                                    padding-bottom: 10px;
                                    border-bottom: 1px solid #e1e2e3
                                }

                                .comment-avatar {
                                    display: inline-block;
                                    vertical-align: top;
                                    margin-right: 10px;
                                    font-size: 0
                                }

                                .comment-text {
                                    display: inline-block;
                                    max-width: 79%;
                                    vertical-align: top;
                                    font-size: 16px
                                }

                                .comment-username {
                                    color: #365899;
                                    font-weight: 700;
                                    margin-right: 10px;
                                    cursor: pointer
                                }

                                .comment-username:hover {
                                    text-decoration: underline
                                }

                                .comment-action {
                                    padding-left: 50px
                                }

                                .like, .like-count, .reply {
                                    color: #365899;
                                    font-size: 13px;
                                    cursor: pointer;
                                    margin-right: 10px;
                                    position: relative;
                                    -webkit-user-select: none;
                                    -moz-user-select: none;
                                    -ms-user-select: none;
                                    user-select: none
                                }

                                .like:hover, .reply:hover {
                                    text-decoration: underline
                                }

                                .like:after, .reply:after {
                                    content: " · ";
                                    position: absolute;
                                    font-weight: 700;
                                    right: -10px;
                                    top: 0;
                                    color: #90949c
                                }

                                .like-count {
                                    padding-left: 20px;
                                    position: relative
                                }

                                .like-count:before {
                                    content: '';
                                    position: absolute;
                                    width: 18px;
                                    height: 18px;
                                    left: 0;
                                    background-image: url(img/like.png)
                                }

                                .like-count-liked {
                                    animation: .5s like-change
                                }

                                .like-count-unliked {
                                    animation: .5s like-unchange
                                }

                                @keyframes like-change {
                                    50% {
                                        top: -10px;
                                        opacity: 0
                                    }
                                    51% {
                                        bottom: -10px
                                    }
                                    100% {
                                        bottom: 0;
                                        opacity: 1
                                    }
                                }

                                @keyframes like-unchange {
                                    50% {
                                        bottom: -10px;
                                        opacity: 0
                                    }
                                    100% {
                                        top: 0;
                                        opacity: 1
                                    }
                                }

                                .comment-date {
                                    font-size: 13px;
                                    color: #90949c;
                                    position: relative
                                }

                                .comment-input {
                                    width: 90%;
                                    margin: 0 auto;
                                    margin-bottom: 20px
                                }

                                .comment-input-area {
                                    display: inline-block;
                                    vertical-align: top;
                                    width: 80%;
                                    font-size: 0;
                                    perspective: 800px
                                }

                                .comment-input input[type=text] {
                                    width: 150px;
                                    box-sizing: border-box;
                                    padding-left: 10px;
                                    padding-top: 5px;
                                    padding-bottom: 5px;
                                    margin-bottom: 10px;
                                    transition: .4s;
                                    word-wrap: wrap
                                }

                                .textarea {
                                    width: 100%;
                                    max-width: 100%;
                                    box-sizing: border-box;
                                    padding-left: 10px;
                                    padding-top: 10px;
                                    padding-bottom: 10px;
                                    height: 40px;
                                    font-family: Arial, sans-serif;
                                    transition: .5s
                                }

                                .textarea-focus {
                                    height: 80px
                                }

                                .input-action {
                                    display: none;
                                    transition: .4s;
                                    background-color: #f6f7f9;
                                    border: 1px solid #ccc;
                                    border-top: none;
                                    padding: 10px 10px;
                                    transform-origin: top;
                                    padding: 10px 10px
                                }

                                .input-action-focus {
                                    display: block;
                                    animation: .6s action-appear
                                }

                                .comment-appear {
                                    animation: comment-appear .4s
                                }

                                @keyframes comment-appear {
                                    from {
                                        transform: scale(0)
                                    }
                                    to {
                                        transform: scale(1)
                                    }
                                }

                                @keyframes action-appear {
                                    0% {
                                        opacity: 0;
                                        transform: rotateX(-90deg)
                                    }
                                    60% {
                                        transform: rotateX(30deg)
                                    }
                                    100% {
                                        opacity: 1;
                                        transform: rotateX(0)
                                    }
                                }

                                .send-btn {
                                    float: right;
                                    padding: 5px 10px;
                                    background-color: #4267b2;
                                    border: none;
                                    border-radius: 2px;
                                    color: #fff;
                                    font-weight: 700;
                                    cursor: pointer
                                }

                                .send-btn:hover {
                                    background-color: #365899
                                }

                                @media all and (max-width: 720px) {
                                    main {
                                        width: 100%
                                    }

                                    .sidebar {
                                        display: none
                                    }

                                    .mobile-header {
                                        display: block
                                    }
                                }

                                .button {
                                    display: inline-block;
                                    vertical-align: top;
                                    text-decoration: none;
                                    font-size: 18px;
                                    padding: 15px 15px;
                                    background-color: #f44336;
                                    color: #fff;
                                    text-align: center;
                                    letter-spacing: .5px;
                                    border: none;
                                    margin: 10px 0;
                                    text-transform: uppercase;
                                    border-radius: 2px;
                                    -webkit-box-shadow: 0 0 2px rgba(0, 0, 0, .12), 0 2px 2px rgba(0, 0, 0, .2);
                                    box-shadow: 0 0 2px rgba(0, 0, 0, .12), 0 2px 2px rgba(0, 0, 0, .2);
                                    transition: .3s ease-out
                                }

                                .button:hover {
                                    background-color: #f55a4e;
                                    box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .14), 0 1px 7px 0 rgba(0, 0, 0, .12), 0 3px 1px -1px rgba(0, 0, 0, .2)
                                }

                                .pulse {
                                    position: relative;
                                    z-index: 1
                                }

                                .pulse:hover:before {
                                    content: '';
                                    display: block;
                                    position: absolute;
                                    width: 100%;
                                    height: 100%;
                                    top: 0;
                                    left: 0;
                                    background-color: #f44336;
                                    border-radius: inherit;
                                    transition: opacity .3s, -webkit-transform .3s;
                                    transition: opacity .3s, transform .3s;
                                    transition: opacity .3s, transform .3s, -webkit-transform .3s;
                                    -webkit-animation: pulse-animation 5s cubic-bezier(.24, 0, .38, 1) infinite;
                                    animation: pulse-animation 5s cubic-bezier(.24, 0, .38, 1) infinite;
                                    z-index: -1
                                }

                                @-webkit-keyframes pulse-animation {
                                    0% {
                                        opacity: 1;
                                        -webkit-transform: scale(1);
                                        transform: scale(1)
                                    }
                                    15% {
                                        opacity: 0;
                                        -webkit-transform: scale(1.2);
                                        transform: scale(1.2)
                                    }
                                    100% {
                                        opacity: 0;
                                        -webkit-transform: scale(1.2);
                                        transform: scale(1.2)
                                    }
                                }

                                @keyframes pulse-animation {
                                    0% {
                                        opacity: 1;
                                        -webkit-transform: scale(1);
                                        transform: scale(1)
                                    }
                                    15% {
                                        opacity: 0;
                                        -webkit-transform: scale(1.2);
                                        transform: scale(1.2)
                                    }
                                    100% {
                                        opacity: 0;
                                        -webkit-transform: scale(1.2);
                                        transform: scale(1.2)
                                    }
                                }


                                .comments-refreshing {
                                    display: none;
                                    text-align: center
                                }

                                .comments-refreshing img {
                                    max-width: 100px
                                }

                                .refresh-appear {
                                    display: block;
                                    animation: typing-show .5s
                                }

                                @keyframes typing-show {
                                    0% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }

                                @keyframes new-comment-show {
                                    0% {
                                        transform: scale(.2)
                                    }
                                    80% {
                                        transform: scale(1.2)
                                    }
                                    100% {
                                        transform: scale(1)
                                    }
                                }

                                .show-message {
                                    font-family: Roboto-Regular
                                }

                                .blink {
                                    color: red !important;
                                    animation-name: blinker;
                                    animation-duration: 1s;
                                    animation-timing-function: linear;
                                    animation-iteration-count: infinite;
                                    -webkit-animation-name: blinker;
                                    -webkit-animation-duration: 1s;
                                    -webkit-animation-timing-function: linear;
                                    -webkit-animation-iteration-count: infinite;
                                    -moz-animation-name: blinker;
                                    -moz-animation-duration: 1s;
                                    -moz-animation-timing-function: linear;
                                    -moz-animation-iteration-count: infinite;
                                    text-decoration: line-through
                                }

                                .show-message p {
                                    margin: 0 !important
                                }

                                .show-message__icon {
                                    width: 50px !important;
                                    display: inline-block;
                                    vertical-align: middle
                                }

                                .show-message__info {
                                    width: 248px;
                                    line-height: normal;
                                    display: inline-block;
                                    margin-left: 15px;
                                    color: #000;
                                    vertical-align: middle;
                                    margin-bottom: 0;
                                    font-size: 19px;
                                    font-family: RobotoRegular, sans-serif
                                }

                                .show-message__info span {
                                    font-size: 20px;
                                    font-family: RobotoRegular, sans-serif
                                }

                                .show-message__left {
                                    font-size: 14px
                                }

                                .show-message__left span {
                                    font-size: 15px
                                }

                                .show-message_call {
                                    background-color: #363636
                                }

                                .show-message__info span {
                                    color: #000
                                }

                                .package_left, .package_left span {
                                    font-size: 15px !important
                                }

                                #ouibounce-modal {
                                    background-color: rgba(0, 0, 0, .9)
                                }

                                .show-message_online {
                                    background-color: #cd5555;
                                    background-color: rgba(0, 0, 0, .9)
                                }

                                .show-message__inner {
                                    line-height: 90px;
                                    display: inline-block;
                                    vertical-align: middle
                                }

                                .show-message__item, .show-message__item-first {
                                    position: fixed;
                                    right: 20px;
                                    top: 120px;
                                    width: 318px;
                                    background-color: rgba(255, 255, 255, .92);
                                    color: #000;
                                    padding: 0 25px;
                                    font-size: 14px;
                                    line-height: 90px;
                                    border-radius: 5px;
                                    display: none;
                                    z-index: 98;
                                    box-sizing: border-box;
                                    border: 2px solid #7474ff;
                                    border-left-style: dashed;
                                    border-right-style: dashed;
                                    text-shadow: 0 0 2px #fff;
                                    box-shadow: 0 0 1px 0;
                                    -webkit-box-shadow: 0 0 1px 0;
                                    -moz-box-shadow: 0 0 1px 0
                                }

                                .lost_position {
                                    display: none !important;
                                    opacity: 0 !important
                                }

                                .block_position {
                                    display: block !important;
                                    opacity: 1 !important
                                }

                                @media screen and (max-width: 767px) {
                                    .show-message__item, .show-message__item-first {
                                        top: auto;
                                        right: 10px;
                                        bottom: 10px
                                    }

                                    .show-message__info {
                                        width: 230px
                                    }

                                    .show-message__item, .show-message__item-first {
                                        width: 300px
                                    }
                                }

                                @media screen and (max-width: 319px) {
                                    .show-message__item, .show-message__item-first {
                                        width: 225px
                                    }

                                    .show-message__info {
                                        width: 160px;
                                        margin-left: 7px;
                                        font-size: 15px
                                    }

                                    .show-message__info span {
                                        font-size: 17px
                                    }

                                    .show-message__icon {
                                        width: 38px !important
                                    }

                                    .show-message__info br {
                                        display: none
                                    }
                                }

                                @-moz-keyframes blinker {
                                    0% {
                                        opacity: 1
                                    }
                                    50% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }

                                @-webkit-keyframes blinker {
                                    0% {
                                        opacity: 1
                                    }
                                    50% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }

                                @keyframes blinker {
                                    0% {
                                        opacity: 1
                                    }
                                    50% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }
                            </style>
                            <style type="text/css">
                                .form-control {
                                    padding: 10px !important;
                                    display: block !important;
                                    margin: 0 auto 20px !important;
                                    padding: 10px !important;
                                    width: 360px !important;
                                    max-width: 100% !important;
                                    border: 2px solid grey !important;
                                    border-radius: 5px !important;
                                }

                                .time_remains {
                                    font-size: 1.1em;
                                    color: red;
                                    font-weight: 700;
                                }

                                p.pricec {
                                    position: absolute;
                                    right: 0;
                                    top: 424px;
                                    color: #000;
                                    width: 160px;
                                    height: 129px;
                                    text-align: center !important;
                                    font-size: 19px;
                                    font-weight: 700;
                                    line-height: 1.3;
                                    -webkit-transform: rotate(-7deg);
                                    transform: rotate(-7deg);
                                    margin: -160px auto 30px;
                                    background: url(../img/star.png);
                                    background-size: contain;
                                    padding-top: 29px;
                                }

                                .submit-form {

                                    display: block;
                                    margin: 40px auto;
                                    padding: 20px;
                                    font-size: 20px;
                                    text-decoration: none;
                                    background-color: #de0606;
                                    text-align: center;
                                    color: #fff !important;
                                    border-radius: 4px;
                                    border: none;
                                    cursor: pointer;
                                    font-family: sans-serif;
                                }

                                p.pricec {
                                    right: 16%;
                                    width: 160px;
                                }

                                p.priceс {
                                    position: relative;
                                    left: 100px;
                                    top: -100px;
                                    color: #000;
                                    box-shadow: rgba(0, 0, 0, .8) 0 3px 30px;
                                    width: 165px;
                                    height: 98px;
                                    text-align: center !important;
                                    font-size: 19px;
                                    font-weight: 700;
                                    line-height: 1.3;
                                    transform: rotateZ(-7deg);
                                    margin: -160px auto 30px;
                                    background: linear-gradient(to right, #eea513 0, #fded13 100%);
                                    border-width: 2px;
                                    border-style: solid;
                                    border-color: #fff;
                                    border-image: initial;
                                    border-radius: 19%
                                }

                                .discountс {
                                    display: block;
                                    margin-top: 9px;
                                    font-size: 16px
                                }

                                .price_main {
                                    border-bottom: 2px solid #d31812;
                                    font-size: 25px;
                                    line-height: 0
                                }

                                .js_old_price {
                                    margin: 0 30px
                                }

                                .Wheel_input {
                                    padding: 10px !important;
                                    display: block !important;
                                    margin: 0 auto !important;
                                    padding: 10px !important;
                                    width: 50% !important;
                                    border: 2px solid grey !important;
                                    border-radius: 5px !important
                                }

                                .country_select {
                                    display: none
                                }

                                .order_form {
                                    display: block !important;
                                    margin: 0 auto !important;
                                    text-align: center !important
                                }

                                @media screen and (max-width: 480px) {
                                    input {
                                        width: 90%
                                    }
                                }

                                .main-link {
                                    display: block;
                                    margin: 20px auto;
                                    padding: 20px;
                                    font-size: 20px;
                                    text-decoration: none;
                                    background-color: #de0606;
                                    text-align: center;
                                    color: #fff !important;
                                    border-radius: 4px;
                                    border: none;
                                    cursor: pointer
                                }

                                .main-link:hover {
                                    opacity: .8
                                }

                                .spin-wrapper {
                                    -webkit-box-shadow: 0 0 10px;
                                    box-shadow: 0 0 10px;
                                    border: 3px solid red;
                                    padding: 20px 10px;
                                    border-radius: 10px;
                                    text-align: center;
                                    box-sizing: border-box
                                }

                                #align .spin-wrapper p {
                                    text-align: center;
                                    font-size: 21px !important;
                                    line-height: 1.4 !important;
                                    margin-bottom: 15px
                                }

                                .wheel-wrapper {
                                    text-align: center
                                }

                                .wheel {
                                    margin: 0 auto;
                                    position: relative
                                }

                                .wheel-cursor {
                                    position: absolute;
                                    width: 35% !important;
                                    height: 35%;
                                    top: 49%;
                                    left: 50%;
                                    -webkit-transform: translate(-50%, -50%);
                                    -ms-transform: translate(-50%, -50%);
                                    transform: translate(-50%, -50%)
                                }

                                .cursor-text {
                                    position: absolute;
                                    z-index: 2;
                                    display: inline-block;
                                    width: 85px !important;
                                    height: 50%;
                                    max-width: 50%;
                                    line-height: 61px;
                                    cursor: pointer;
                                    border-radius: 50%;
                                    vertical-align: middle;
                                    text-align: center;
                                    background-color: #ccc;
                                    border: 1px solid #ccc;
                                    top: 47%;
                                    left: 50%;
                                    -webkit-user-select: none;
                                    -moz-user-select: none;
                                    -ms-user-select: none;
                                    user-select: none;
                                    -webkit-transform: translate(-50%, -50%);
                                    -ms-transform: translate(-50%, -50%);
                                    transform: translate(-50%, -50%);
                                    -webkit-box-shadow: rgb(255 255 255) 0 -2px 0 inset, rgb(255 255 255) 0 2px 0 inset, rgb(0 0 0 / 40%) 0 0 5px;
                                    box-shadow: rgb(255 255 255) 0 -2px 0 inset, rgb(255 255 255) 0 2px 0 inset, rgb(0 0 0 / 40%) 0 0 5px;
                                    background: #fff;
                                    background: -webkit-gradient(radial, center center, 0, center center, 100%, color-stop(0, rgba(255, 255, 255, 1)), color-stop(100%, rgba(234, 234, 234, 1)));
                                    background: -webkit-radial-gradient(center, ellipse cover, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
                                    background: -o-radial-gradient(center, ellipse cover, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
                                    background: -webkit-radial-gradient(center, ellipse, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
                                    background: -o-radial-gradient(center, ellipse, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);
                                    background: radial-gradient(ellipse at center, rgba(255, 255, 255, 1) 0, rgba(234, 234, 234, 1) 100%);

                                    display: flex;
                                    justify-content: center;
                                    align-items: center;
                                }

                                .wheel-img {
                                    -webkit-transition: 4s;
                                    -o-transition: 4s;
                                    transition: 4s
                                }

                                .close-popup {
                                    position: absolute;
                                    width: 30px;
                                    height: 30px;

                                    background-size: 100%;
                                    top: -40px;
                                    border-radius: 50%;
                                    -webkit-box-shadow: 0 0 10px #fff;
                                    box-shadow: 0 0 10px #fff;
                                    right: -40px;
                                    cursor: pointer
                                }

                                .cursor-text:active {
                                    -webkit-box-shadow: rgba(0, 0, 0, .4) 0 0 5px inset;
                                    box-shadow: rgba(0, 0, 0, .4) 0 0 5px inset
                                }

                                .spin-result-wrapper {
                                    display: none;
                                    padding: 0 10px;
                                    -webkit-box-sizing: border-box;
                                    box-sizing: border-box;
                                    width: 100%;
                                    top: 0;
                                    z-index: 999;
                                    left: 0;
                                    height: 100%;
                                    position: fixed;
                                    background-color: rgba(0, 0, 0, .6);
                                    text-align: center
                                }

                                .pop-up-layer {
                                    position: fixed !important;
                                    top: 0 !important;
                                    width: 100% !important;
                                    height: 100% !important;
                                    background-color: rgba(0, 0, 0, .7) !important;
                                    z-index: 99 !important
                                }

                                .pop-up-layer-show {
                                    display: block
                                }

                                .pop-up-window {
                                    position: relative;
                                    max-width: 400px;
                                    right: 0;
                                    left: 0;
                                    top: 40%;
                                    margin: 0 auto;
                                    background: #fff none repeat scroll 0 0;
                                    text-align: center;
                                    padding: 10px;
                                    padding-top: 70px;
                                    padding-bottom: 20px;
                                    border-radius: 10px;
                                    animation: .7s ease 0s normal none 1 running pop-up-appear
                                }

                                .pop-up-window::before {
                                    content: "";
                                    position: absolute;
                                    width: 110px;
                                    height: 110px;
                                    top: -55px;
                                    left: 0;
                                    right: 0;
                                    margin: 0 auto;
                                    background-color: #42b7e0;
                                    border-radius: 50%;
                                    animation: .5s ease .6s normal backwards 1 running pop-up-appear-before
                                }

                                .pop-up-window::after {
                                    content: "";
                                    position: absolute;
                                    width: 50px;
                                    height: 20px;
                                    top: -20px;
                                    left: 0;
                                    right: 0;
                                    margin: 0 auto;
                                    border-width: medium medium 4px 4px;
                                    border-style: none none solid solid;
                                    border-color: currentcolor currentcolor #fff #fff;
                                    -moz-border-top-colors: none;
                                    -moz-border-right-colors: none;
                                    -moz-border-bottom-colors: none;
                                    -moz-border-left-colors: none;
                                    border-image: none;
                                    transform: rotate(-45deg);
                                    transition: opacity 1s ease 0s;
                                    animation: .5s ease .6s normal backwards 1 running pop-up-appear-after
                                }

                                @keyframes pop-up-appear {
                                    0% {
                                        transform: translateY(-2000px)
                                    }
                                    30% {
                                        transform: translateY(100px)
                                    }
                                    100% {
                                        transform: translateY(0)
                                    }
                                }

                                @keyframes pop-up-appear-before {
                                    0% {
                                        transform: scale(0)
                                    }
                                    100% {
                                        transform: scale(1)
                                    }
                                }

                                @keyframes pop-up-appear-after {
                                    0% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }

                                .pop-up-heading {
                                    font-size: 35px;
                                    margin-bottom: 20px
                                }

                                .pop-up-text {
                                    margin-bottom: 25px;
                                    font-size: 24px;
                                    line-height: 30px;
                                    text-align: center
                                }

                                .pop-up-button {
                                    text-transform: uppercase;
                                    text-decoration: none;
                                    padding: 10px 20%;
                                    font-size: 20px;
                                    border-radius: 5px;
                                    background-color: #42b7e0;
                                    color: #fff !important;
                                    border: medium none;
                                    cursor: pointer;
                                    outline: medium none
                                }

                                .pop-up-button:hover {
                                    color: #fff;
                                    text-decoration: none
                                }

                                .wheel img {
                                    max-width: 100%;
                                    display: block;
                                    margin: 0 auto;
                                }

                                @media all and (max-width: 520px) {
                                    .cursor-text {
                                        line-height: 48px;
                                        font-size: 14px;
                                        top: 52%
                                    }

                                    .close-popup {
                                        position: absolute;
                                        width: 30px;
                                        height: 30px;
                                        background-image: url(img/cross.svg);
                                        background-size: 100%;
                                        top: -40px;
                                        border-radius: 50%;
                                        -webkit-box-shadow: 0 0 10px #fff;
                                        box-shadow: 0 0 10px #fff;
                                        right: -10px;
                                        cursor: pointer
                                    }

                                    p.priceс {
                                        top: -120px;
                                        left: 20px
                                    }
                                }

                                .super-rotation {
                                    -webkit-animation-name: super-rotation;
                                    animation-name: super-rotation;
                                    -webkit-animation-duration: 7s;
                                    animation-duration: 7s;
                                    -webkit-animation-fill-mode: forwards;
                                    animation-fill-mode: forwards;
                                    -webkit-transition-timing-function: ease-in-out;
                                    -o-transition-timing-function: ease-in-out;
                                    transition-timing-function: ease-in-out
                                }

                                @-webkit-keyframes super-rotation {
                                    70% {
                                        -webkit-transform: rotate(1783deg);
                                        transform: rotate(1783deg)
                                    }
                                    100% {
                                        -webkit-transform: rotate(1774deg);
                                        transform: rotate(1774deg)
                                    }
                                }

                                @keyframes super-rotation {
                                    70% {
                                        -webkit-transform: rotate(1783deg);
                                        transform: rotate(1783deg)
                                    }
                                    100% {
                                        -webkit-transform: rotate(1774deg);
                                        transform: rotate(1774deg)
                                    }
                                }

                                .time_remains {
                                    font-size: 1.1em;
                                    color: red;
                                    font-weight: 700
                                }

                                .time_remains_title {
                                    padding-top: 15px;
                                    text-align: center;
                                    font-size: 22px
                                }

                                .comments {
                                    padding-top: 10px
                                }

                                .comments-item {
                                    max-width: 90%;
                                    box-sizing: border-box;
                                    margin: 0 auto;
                                    margin-bottom: 15px;
                                    padding-bottom: 10px;
                                    border-bottom: 1px solid #e1e2e3
                                }

                                .comment-avatar {
                                    display: inline-block;
                                    vertical-align: top;
                                    margin-right: 10px;
                                    font-size: 0
                                }

                                .comment-text {
                                    display: inline-block;
                                    max-width: 79%;
                                    vertical-align: top;
                                    font-size: 16px
                                }

                                .comment-username {
                                    color: #365899;
                                    font-weight: 700;
                                    margin-right: 10px;
                                    cursor: pointer
                                }

                                .comment-username:hover {
                                    text-decoration: underline
                                }

                                .comment-action {
                                    padding-left: 50px
                                }

                                .like, .like-count, .reply {
                                    color: #365899;
                                    font-size: 13px;
                                    cursor: pointer;
                                    margin-right: 10px;
                                    position: relative;
                                    -webkit-user-select: none;
                                    -moz-user-select: none;
                                    -ms-user-select: none;
                                    user-select: none
                                }

                                .like:hover, .reply:hover {
                                    text-decoration: underline
                                }

                                .like:after, .reply:after {
                                    content: " · ";
                                    position: absolute;
                                    font-weight: 700;
                                    right: -10px;
                                    top: 0;
                                    color: #90949c
                                }

                                .like-count {
                                    padding-left: 20px;
                                    position: relative
                                }

                                .like-count:before {
                                    content: '';
                                    position: absolute;
                                    width: 18px;
                                    height: 18px;
                                    left: 0;
                                    background-image: url(img/like.png)
                                }

                                .like-count-liked {
                                    animation: .5s like-change
                                }

                                .like-count-unliked {
                                    animation: .5s like-unchange
                                }

                                @keyframes like-change {
                                    50% {
                                        top: -10px;
                                        opacity: 0
                                    }
                                    51% {
                                        bottom: -10px
                                    }
                                    100% {
                                        bottom: 0;
                                        opacity: 1
                                    }
                                }

                                @keyframes like-unchange {
                                    50% {
                                        bottom: -10px;
                                        opacity: 0
                                    }
                                    100% {
                                        top: 0;
                                        opacity: 1
                                    }
                                }

                                .comment-date {
                                    font-size: 13px;
                                    color: #90949c;
                                    position: relative
                                }

                                .comment-input {
                                    width: 90%;
                                    margin: 0 auto;
                                    margin-bottom: 20px
                                }

                                .comment-input-area {
                                    display: inline-block;
                                    vertical-align: top;
                                    width: 80%;
                                    font-size: 0;
                                    perspective: 800px
                                }

                                .comment-input input[type=text] {
                                    width: 150px;
                                    box-sizing: border-box;
                                    padding-left: 10px;
                                    padding-top: 5px;
                                    padding-bottom: 5px;
                                    margin-bottom: 10px;
                                    transition: .4s;
                                    word-wrap: wrap
                                }

                                .textarea {
                                    width: 100%;
                                    max-width: 100%;
                                    box-sizing: border-box;
                                    padding-left: 10px;
                                    padding-top: 10px;
                                    padding-bottom: 10px;
                                    height: 40px;
                                    font-family: Arial, sans-serif;
                                    transition: .5s
                                }

                                .textarea-focus {
                                    height: 80px
                                }

                                .input-action {
                                    display: none;
                                    transition: .4s;
                                    background-color: #f6f7f9;
                                    border: 1px solid #ccc;
                                    border-top: none;
                                    padding: 10px 10px;
                                    transform-origin: top;
                                    padding: 10px 10px
                                }

                                .input-action-focus {
                                    display: block;
                                    animation: .6s action-appear
                                }

                                .comment-appear {
                                    animation: comment-appear .4s
                                }

                                @keyframes comment-appear {
                                    from {
                                        transform: scale(0)
                                    }
                                    to {
                                        transform: scale(1)
                                    }
                                }

                                @keyframes action-appear {
                                    0% {
                                        opacity: 0;
                                        transform: rotateX(-90deg)
                                    }
                                    60% {
                                        transform: rotateX(30deg)
                                    }
                                    100% {
                                        opacity: 1;
                                        transform: rotateX(0)
                                    }
                                }

                                .send-btn {
                                    float: right;
                                    padding: 5px 10px;
                                    background-color: #4267b2;
                                    border: none;
                                    border-radius: 2px;
                                    color: #fff;
                                    font-weight: 700;
                                    cursor: pointer
                                }

                                .send-btn:hover {
                                    background-color: #365899
                                }

                                @media all and (max-width: 720px) {
                                    main {
                                        width: 100%
                                    }

                                    .sidebar {
                                        display: none
                                    }

                                    .mobile-header {
                                        display: block
                                    }
                                }

                                .button {
                                    display: inline-block;
                                    vertical-align: top;
                                    text-decoration: none;
                                    font-size: 18px;
                                    padding: 15px 15px;
                                    background-color: #f44336;
                                    color: #fff;
                                    text-align: center;
                                    letter-spacing: .5px;
                                    border: none;
                                    margin: 10px 0;
                                    text-transform: uppercase;
                                    border-radius: 2px;
                                    -webkit-box-shadow: 0 0 2px rgba(0, 0, 0, .12), 0 2px 2px rgba(0, 0, 0, .2);
                                    box-shadow: 0 0 2px rgba(0, 0, 0, .12), 0 2px 2px rgba(0, 0, 0, .2);
                                    transition: .3s ease-out
                                }

                                .button:hover {
                                    background-color: #f55a4e;
                                    box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .14), 0 1px 7px 0 rgba(0, 0, 0, .12), 0 3px 1px -1px rgba(0, 0, 0, .2)
                                }

                                .pulse {
                                    position: relative;
                                    z-index: 1
                                }

                                .pulse:hover:before {
                                    content: '';
                                    display: block;
                                    position: absolute;
                                    width: 100%;
                                    height: 100%;
                                    top: 0;
                                    left: 0;
                                    background-color: #f44336;
                                    border-radius: inherit;
                                    transition: opacity .3s, -webkit-transform .3s;
                                    transition: opacity .3s, transform .3s;
                                    transition: opacity .3s, transform .3s, -webkit-transform .3s;
                                    -webkit-animation: pulse-animation 5s cubic-bezier(.24, 0, .38, 1) infinite;
                                    animation: pulse-animation 5s cubic-bezier(.24, 0, .38, 1) infinite;
                                    z-index: -1
                                }

                                @-webkit-keyframes pulse-animation {
                                    0% {
                                        opacity: 1;
                                        -webkit-transform: scale(1);
                                        transform: scale(1)
                                    }
                                    15% {
                                        opacity: 0;
                                        -webkit-transform: scale(1.2);
                                        transform: scale(1.2)
                                    }
                                    100% {
                                        opacity: 0;
                                        -webkit-transform: scale(1.2);
                                        transform: scale(1.2)
                                    }
                                }

                                @keyframes pulse-animation {
                                    0% {
                                        opacity: 1;
                                        -webkit-transform: scale(1);
                                        transform: scale(1)
                                    }
                                    15% {
                                        opacity: 0;
                                        -webkit-transform: scale(1.2);
                                        transform: scale(1.2)
                                    }
                                    100% {
                                        opacity: 0;
                                        -webkit-transform: scale(1.2);
                                        transform: scale(1.2)
                                    }
                                }


                                .comments-refreshing {
                                    display: none;
                                    text-align: center
                                }

                                .comments-refreshing img {
                                    max-width: 100px
                                }

                                .refresh-appear {
                                    display: block;
                                    animation: typing-show .5s
                                }

                                @keyframes typing-show {
                                    0% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }

                                @keyframes new-comment-show {
                                    0% {
                                        transform: scale(.2)
                                    }
                                    80% {
                                        transform: scale(1.2)
                                    }
                                    100% {
                                        transform: scale(1)
                                    }
                                }

                                .show-message {
                                    font-family: Roboto-Regular
                                }

                                .blink {
                                    color: red !important;
                                    animation-name: blinker;
                                    animation-duration: 1s;
                                    animation-timing-function: linear;
                                    animation-iteration-count: infinite;
                                    -webkit-animation-name: blinker;
                                    -webkit-animation-duration: 1s;
                                    -webkit-animation-timing-function: linear;
                                    -webkit-animation-iteration-count: infinite;
                                    -moz-animation-name: blinker;
                                    -moz-animation-duration: 1s;
                                    -moz-animation-timing-function: linear;
                                    -moz-animation-iteration-count: infinite;
                                    text-decoration: line-through
                                }

                                .show-message p {
                                    margin: 0 !important
                                }

                                .show-message__icon {
                                    width: 50px !important;
                                    display: inline-block;
                                    vertical-align: middle
                                }

                                .show-message__info {
                                    width: 248px;
                                    line-height: normal;
                                    display: inline-block;
                                    margin-left: 15px;
                                    color: #000;
                                    vertical-align: middle;
                                    margin-bottom: 0;
                                    font-size: 19px;
                                    font-family: RobotoRegular, sans-serif
                                }

                                .show-message__info span {
                                    font-size: 20px;
                                    font-family: RobotoRegular, sans-serif
                                }

                                .show-message__left {
                                    font-size: 14px
                                }

                                .show-message__left span {
                                    font-size: 15px
                                }

                                .show-message_call {
                                    background-color: #363636
                                }

                                .show-message__info span {
                                    color: #000
                                }

                                .package_left, .package_left span {
                                    font-size: 15px !important
                                }

                                #ouibounce-modal {
                                    background-color: rgba(0, 0, 0, .9)
                                }

                                .show-message_online {
                                    background-color: #cd5555;
                                    background-color: rgba(0, 0, 0, .9)
                                }

                                .show-message__inner {
                                    line-height: 90px;
                                    display: inline-block;
                                    vertical-align: middle
                                }

                                .show-message__item, .show-message__item-first {
                                    position: fixed;
                                    right: 20px;
                                    top: 120px;
                                    width: 318px;
                                    background-color: rgba(255, 255, 255, .92);
                                    color: #000;
                                    padding: 0 25px;
                                    font-size: 14px;
                                    line-height: 90px;
                                    border-radius: 5px;
                                    display: none;
                                    z-index: 98;
                                    box-sizing: border-box;
                                    border: 2px solid #7474ff;
                                    border-left-style: dashed;
                                    border-right-style: dashed;
                                    text-shadow: 0 0 2px #fff;
                                    box-shadow: 0 0 1px 0;
                                    -webkit-box-shadow: 0 0 1px 0;
                                    -moz-box-shadow: 0 0 1px 0
                                }

                                .lost_position {
                                    display: none !important;
                                    opacity: 0 !important
                                }

                                .block_position {
                                    display: block !important;
                                    opacity: 1 !important
                                }

                                @media screen and (max-width: 767px) {
                                    .show-message__item, .show-message__item-first {
                                        top: auto;
                                        right: 10px;
                                        bottom: 10px
                                    }

                                    .show-message__info {
                                        width: 230px
                                    }

                                    .show-message__item, .show-message__item-first {
                                        width: 300px
                                    }
                                }

                                @media screen and (max-width: 319px) {
                                    .show-message__item, .show-message__item-first {
                                        width: 225px
                                    }

                                    .show-message__info {
                                        width: 160px;
                                        margin-left: 7px;
                                        font-size: 15px
                                    }

                                    .show-message__info span {
                                        font-size: 17px
                                    }

                                    .show-message__icon {
                                        width: 38px !important
                                    }

                                    .show-message__info br {
                                        display: none
                                    }
                                }

                                @-moz-keyframes blinker {
                                    0% {
                                        opacity: 1
                                    }
                                    50% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }

                                @-webkit-keyframes blinker {
                                    0% {
                                        opacity: 1
                                    }
                                    50% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }

                                @keyframes blinker {
                                    0% {
                                        opacity: 1
                                    }
                                    50% {
                                        opacity: 0
                                    }
                                    100% {
                                        opacity: 1
                                    }
                                }</style>
                            <h2 class="time_remains_title">Offer valid until (inclusive):
                                <span class="time_remains">
                                    <script>
                                        dtime_nums(0, true)
                                    </script>
                                </span>
                            </h2>
                        </div>


                        <p></p>
                    </div>
                    <div class="buzzplayer-stage"></div>
                </div>
                <center>This is not a medical product</center>
            </article>
            <aside class="col-300 base-aside">
                <div class="banner-main_top external_banner">

                    <div id="adfox_150641665618168353"><a class="landing_link_js" href="#toform"
                                                          target="_blank"><img src="img/2360160.png"
                                                                               style="width: 100%; height: auto; border: 0px; vertical-align: middle; max-width: 300px;"></a>
                    </div>
                </div>

                <div class="tag-wrapper hidden">
                    <ol class="tag-item">
                        <li><a class="landing_link_js" href="#toform" target="_blank">

                        </a>
                            <a class="landing_link_js" href="#toform" target="_blank" class="name">katyanochek</a>
                            <span class="name-rate">357371</span>
                        </li>
                        <li><a class="landing_link_js" href="#toform" target="_blank">
                            <img src="." alt="Lizbeth" height="50" width="50">
                        </a>
                            <a class="landing_link_js" href="#toform" target="_blank" class="name">Lizbeth</a>
                            <span class="name-rate">501366</span>
                        </li>
                        <li><a class="landing_link_js" href="#toform" target="_blank">
                            <img src="." alt="arizonadream" height="50" width="50">
                        </a>
                            <a class="landing_link_js" href="#toform" target="_blank"
                               class="name">arizonadream</a>
                            <span class="name-rate">334400</span>
                        </li>
                        <li><a class="landing_link_js" href="#toform" target="_blank">
                            <img src="." alt="Skarletty" height="50" width="50">
                        </a>
                            <a class="landing_link_js" href="#toform" target="_blank" class="name">Skay</a>
                            <span class="name-rate">938473</span>
                        </li>
                    </ol>
                </div>
        </div>
</div>
<div class="external_banner">

    <div id="adfox_150641740188382216"></div>
</div>
</aside>
</div>
<div class="article-footer">
</div>
<meta content="40">
<div id="comments" class="col-wrapper comments-wrapper comment-page">
    <div class="">
        <a id="forum"></a>
        <h4 class="comment-header">Comments</h4>
        <div class="comments-list">
            <section id="comment-8326048" class="article-preview_comments post-edit" itemscope="">
                <div itemscope="">
                    <meta content="Ternovnik">
                    <meta>
                </div>
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Akinwale
                    Michael</a>
                <meta content="0">
                <meta content="2">
                <div id="comment-8326048-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/albina.jpg" alt="Ternovnik" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326048-content" style="">
                            Guys, highly recommend! Girlfriend delighted!<a class="landing_link_js"
                                                                            href="#toform" target="_blank">
                            Long Jack XXXL </a></p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326052" class="article-preview_comments post-edit" itemscope="">
                <div itemscope="">
                    <meta content="SNAT4">
                    <meta>
                </div>
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Harnu
                    World</a>
                <meta content="0">
                <meta content="37">
                <div id="comment-8326052-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/lilia.jpg" alt="SNAT4" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326052-content" style="">I bought it, I liked it! thank</p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326190" class="article-preview_comments post-edit" itemscope="">
                <div itemscope="">
                    <meta content="GoodLuck">
                    <meta>
                </div>
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Jes
                    Nwani</a>
                <meta content="0">
                <meta content="9">
                <div id="comment-8326190-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/olesa.jpg" alt="GoodLuck" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326190-content" style="">I really like this <a class="landing_link_js"
                                                                                       href="#toform"
                                                                                       target="_blank">Long Jack XXXL</a>)))
                            libido boost ... I can not believe))))</p>

                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326208" class="article-preview_comments post-edit" itemscope="">
                <div itemscope="">
                    <meta content="Valleta">
                    <meta>
                </div>
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">
                    Okora Anayo</a>
                <meta content="0">
                <meta content="9">
                <div id="comment-8326208-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/olga.jpg" alt="Valleta" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326208-content" style="">Husband shy to order) ordered it to him, a male libido
                            increased after 10 days. Thank you!</p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <!---
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
               <div itemscope="">
                  <meta content="mery">
                  <meta>
               </div>
               <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">
            Folas Arowosegbe</a>
               <meta content="0">
               <meta content="1">
               <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span class="like-number"></span><span class="like"></span></div>
               <div class="comment-body">
                  <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img src="./infodetox1/katerina.jpg" alt="mery" height="50" width="50" class=""></a>
                  <div class="comment-text ">
                     <p id="comment-8326224-content" style=""> I unsubscribe as promised. Satisfied, like an elephant! +12 cm per month. This I did not expect)))</p>
                  </div>
               </div>
               <time class="date">
               18.11.2018
               </time>
            </section>
            ---->
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Den
                    Knavi</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/diana.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">Not enlargement but once tried a weird knock-off viagra
                            bought online. Gave me the dongest of dongs for a good few hours but also made my vision go
                            BLUE. Everything BLUE. Slept it off and woke up to normal vision.
                            Then I tried this and it worked. And without the side effects.
                            I recommend <a class="landing_link_js" href="#toform" target="_blank"> Long Jack XXXL</a></p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Bnav
                    Colachu</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/irina.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">
                            I have been taking pills for 16 days already. Libido boost !! <a class="landing_link_js"
                                                                                             href="#toform"
                                                                                             target="_blank"> Long Jack XXXL</a>
                        </p>

                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Ibid
                    Okusi</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/vik.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">Wow people, I also want so! (((I ran to order, then
                            accomplish my goal</p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Sakir
                    Alao</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/irina2.png" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">Well, I praise my results on <a class="landing_link_js"
                                                                                                 href="#toform"
                                                                                                 target="_blank">
                            Long Jack XXXL </a>

                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Veronica
                    Izegbu</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/evg.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">I ordered - my husband will have a birthday present)))
                            why give something that is useless, right?</p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Naty</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/nat.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">
                            I want to express my deep gratitude to the creators!!! My husband really helped !!! </p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Dan</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/tany.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">
                            But I did not take it to increase. I work for days in the office chair, and at night - in
                            the driver's, sedentary work adversely affected my erection. Apparently the problem is blood
                            circulation or something. In general, it was with me ... or rather, THIS didn’t last for a
                            long time, but now everything is in the past) I am healthy!) And I don’t plan to return to
                            it anymore) If something goes straight for the pill!</p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Kan</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/darina.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">Thank you for the feedback, the pill is, in fact,
                            unique in its kind, I am talking to you as a doctor !!!</p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-3, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Jann </a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/galina.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">In stores you will not find such pills <a
                                class="landing_link_js" href="#toform" target="_blank"> Long Jack XXXL </a>,
                            On the site at least there is a guarantee, I now only take it there. Just a little left to
                            throw))
                        </p>

                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-2, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Min</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/olga2.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">Very interesting information.
                            I am a skeptic, but I will still try, because you need to fight whenever possible. <a
                                    class="landing_link_js" href="#toform" target="_blank"> Long Jack XXXL</a>
                        </p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(-2, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a href="#toform"></a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">

                    <time class="date">
                        <script type="text/javascript">dtime_nums(0, true)</script>
                    </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Navy</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/kse.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">Girlfriend delighted!</p>
                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(0, true)</script>
                </time>
            </section>
            <section id="comment-8326224" class="article-preview_comments post-edit" itemscope="">
                <a class="landing_link_js" href="#toform" target="_blank" class="nickname nickname_margin-l_-70">Lenny</a>
                <div id="comment-8326224-rating" class="like-dislike"><span class="dislike"></span><span
                        class="like-number"></span><span class="like"></span></div>
                <div class="comment-body">
                    <a class="landing_link_js" href="#toform" target="_blank" class="user_avatar"><img
                            src="img/karina.jpg" alt="mery" height="50" width="50" class=""></a>
                    <div class="comment-text ">
                        <p id="comment-8326224-content" style="">In the west, such a pills has been used for a long
                            time. And quite successfully. As always, everything comes to us with a delay ... <a
                                    class="landing_link_js" href="#toform" target="_blank"> Long Jack XXXL</a>
                            I’m feeling very secure now and my wife has not stopped thanking me for not
                            given up hope to save our marriage.</p>

                    </div>
                </div>
                <time class="date">
                    <script type="text/javascript">dtime_nums(0, true)</script>
                </time>
            </section>
            <center>
                <a class="landing_link_js" href="#toform" target="_blank"
                   style="text-decoration: none; color: white;">
                    <button class="button" type="submit"
                            style="background-color: red; color: #fff; padding: 17px 102px; border-radius: 10px; font-size: 1.5rem; text-transform: uppercase; white-space: nowrap; text-decoration: none; font-weight: 700; display: block; margin: 15px auto;">
                        Buy now
                    </button>
                </a>
            </center>
            <footer aria-role="contentinfo" class="site-footer">
                <center>
                    <p>
                        <span class="hidden-xs hidden-sm">&nbsp;&nbsp;|&nbsp;&nbsp;</span>Copyright ©
                        <script type="text/javascript">
                            var d = new Date();
                            document.write(d.getFullYear());
                        </script>
                        Ehis Ohunyon blog, Inc.
                        All rights reserved.
                    </p>
                </center>
                <div class="links">
                        <style type="text/css">
                            .links {
                                padding: 20px 0;
                                text-align: center;
                            }

                            .links a {
                                color: #000;
                                font-size: 14px;
                                text-decoration: none;
                            }

                            .my_select {
                                -webkit-appearance: none;
                                -moz-appearance: none;
                                appearance: none;
                            }

                        </style>
                        <a href="{TERMS_URL}" target="_blank">Terms &amp;
                            Conditions | </a>
                        <a href="{PRIVACY_POLICY_URL}" target="_blank">Privacy
                            Policy | </a>
                        <a target="_blank" href="{RETURNS_URL}">Returns,
                            Refunds and Exchanges Policy</a>

                    </div>

            </footer>
        </div>
    </div>
</div>
</div>
</main>
<div class="timer__wrap">
    <div class="timer">
        Your promotional rate will end after:
        <span class="count">
        <span style="display: none;" class="time_remains" id="hour">00</span><span class="time_remains" id="min">20</span> : <span class="time_remains" id="sec">00</span>
    </span>
    </div>
</div>
<div class="alert">
    <img src="img/2360160.png" alt="Bio Prost" class="alert__img">
    <span><span class="alert__name">Miran</span> from <span class="alert__city">Lagos</span> just ordered <span class="alert__count">2</span> bottles of Long Jack XXXL</span>
</div>
<script src="js/Timer.js"></script>
<script src="js/main.js"></script>
<script src="js/landWheel.js"></script>

<script>
        function validateForm(t, e) {
            e.preventDefault();
            var r = (t.querySelectorAll("select[name='target_geo_hash'] option:checked")[0], t.querySelectorAll(
                "input[name='phone']")[0]);
            if (r.value.length < 5 || "string" != typeof r.value) return alert(INCORRECT_PHONE_NUMBER_MSG), !1;
            LeadCreator.disableSubmitBtns(), t.submit()
        }

        function getUrlParam(t) {
            var e = {},
                r = decodeURI(window.location.href),
                a = r.indexOf("?"),
                n = r.indexOf("#");
            a < 0 && n > 0 && (r = r.replace("#", "?"), a = n), a > 0 && n > 0 && (r = r.replace("#", "&"));
            for (var i = r.slice(a + 1).split("&"), o = 0; o < i.length; o++) {
                var s = i[o].split("=");
                e[s[0]] = s[1]
            }
            return e[t] || null
        }
        var INCORRECT_PHONE_NUMBER_MSG = "Please enter a valid phone number",
            additional_GET_params = ["clickid", "gvic"],
            link_to_landing = "../landing/",
            LeadCreator = {
                _exists_additional_params: {
                    data: {},
                    put: function (t, e) {
                        this.data[t] = e
                    },
                    get: function (t) {
                        return this.data[t]
                    },
                    serialize: function () {
                        var t = [];
                        for (var e in this.data) this.data.hasOwnProperty(e) && t.push(encodeURIComponent(e) + "=" +
                            encodeURIComponent(this.data[e]));
                        return t.join("&")
                    }
                },
                initCountriesSelect: function () {
                    $(".js-select").on("change", function () {
                        var t = $(this).find("option:selected");
                        LeadCreator.changePrices(t.data("price"), t.data("old_price"), t.data("discount"))
                    })
                },
                changePrices: function (t, e, r) {
                    $(".x_currency").text(t), $(".x_currency_old").text(e), $(".x_discount").text(r)
                },
                processLinksHref: function () {
                    var t = document.querySelectorAll('a[href="' + link_to_landing + '"]');
                    if (t.length < 1) return !1;
                    for (var e = 0; e < t.length; e++) {
                        var r = this._exists_additional_params.serialize();
                        t[e].setAttribute("href", link_to_landing + (r.length > 0 ? "?" + r : ""))
                    }
                },
                processFormAttrs: function () {
                    var t = document.querySelectorAll("form.form_order");
                    if (t.length < 1) return !1;
                    for (var e = 0; e < t.length; e++) {
                        var r = this._exists_additional_params.serialize();
                        t[e].setAttribute("action", "success.php" + (r.length > 0 ? "?" + r : "")), t[e]
                            .setAttribute("onsubmit", "return validateForm(this, event);"), LeadCreator
                            .initKeitaroFormFields(t[e])
                    }
                },
                initKeitaroFormFields: function (t) {
                    var e = $(".keitaro-hidden-input");
                    if (e.length < 1) return !1;
                    for (i = 0; i < e.length; i++) {
                        var r = $(e[i]).clone();
                        r.removeClass("keitaro-hidden-input"), $(t).append(r)
                    }
                },
                setAddittionalParams: function () {
                    for (var t = 0; t < additional_GET_params.length; t++) null !== getUrlParam(
                        additional_GET_params[t]) && this._exists_additional_params.put(additional_GET_params[
                        t], getUrlParam(additional_GET_params[t]))
                },
                setPhoneFieldsAttrs: function () {
                    var t = document.querySelectorAll("input[name='phone']");
                    if (t.length < 1) return !1;
                    for (var e = 0; e < t.length; e++) t[e].setAttribute("required", "true"), t[e].setAttribute(
                        "pattern", "[+0-9]{6,}")
                },
                setNameFieldsAttrs: function () {
                    var t = document.querySelectorAll("input[name='client']");
                    if (t.length < 1) return !1;
                    for (var e = 0; e < t.length; e++) t[e].removeAttribute("required")
                },
                getDefaultCountyOption: function () {
                    return $(".js-select").first().find("option:selected")
                },
                disableSubmitBtns: function () {
                    $(".submit_btn, [type=submit]").attr("disabled", "disabled").css("opacity", .5).css(
                        "pointer-events", "none")
                }
            };
        $(document).ready(function () {
            App.init()
        });
        var App = {
            init: function () {
                LeadCreator.initCountriesSelect();
                var t = LeadCreator.getDefaultCountyOption();
                LeadCreator.changePrices(t.data("price"), t.data("old_price"), t.data("discount")), LeadCreator
                    .setAddittionalParams(), LeadCreator.processLinksHref(), LeadCreator.processFormAttrs(),
                    LeadCreator.setPhoneFieldsAttrs(), LeadCreator.setNameFieldsAttrs()
            }
        };
    </script>

</body>
</html>