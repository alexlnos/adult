<!DOCTYPE html>
<html>

<head>

	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<title>Order Dragon Size!</title>
	<meta content="initial-scale=1, width=device-width" name="viewport">
	<link href="favicon.ico" rel="icon">
	<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
	<link href="css/style.min.css" media="all" rel="stylesheet" type="text/css">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>

	<div id="wrapper">
		<div class="container">
			<header id="header">
				<img src="img/mens-health-life.png">
				<div class="menu">
					<ul>
						<li> <a href="#to_form">Home</a></li>
						<li> <a href="#to_form">News</a></li>
						<li> <a href="#to_form">Date tips</a></li>
						<li> <a href="#to_form">Goods</a></li>
						<li> <a href="#to_form">Sexual experience of readers</a></li>
					</ul>
				</div>
				<div class="headbeyaz">
					<div class="head">
						<span>NEWS<b>18+</b> </span>
					</div>
				</div>
				<div class="ustbaslik">
					<center> ATTENTION! MEDICAL BREAKTHROUGH ONLY FOR MEN WITH SMALL PENIS! </center>
				</div>
			</header>
			<div class="contentsol">
				<p class="inL_106399">
					<span class="inL_772091"><span class="date-18">
							<script type="text/javascript">
								dtime_nums(-16, true)
							</script>
						</span></span>
				</p>
				<h1>
					<img src="img/sexelongplus-a659130e87.jpg">
					<div>+3.2 CM IN ONE MONTH <a href="#to_form" class="new-length nowrap">+3.2 CM IN ONE MONTH</a>
					</div>
				</h1>
				<p> Dear readers!</p>
				<p>We are finally able to share it with you!</p>
				<p> We had been keeping it a secret before we told you.</p>
				<p> If you have been reading us for a long time, you know that we often share articles about natural
					medicines and treatments. It's products with scientifically proven efficacy that the masses are
					silent about. </p>
				<p>Today we will share with you stories where one cream-gel helped more than 9,000 men add 2-4 CM to
					their size. He also had increased their sexual endurance and self-confidence. Women call this drug
					'Lady's dream' because their men now give them a real pleasure.</p>
				<div class="ctevid">
					<div class="video video2 inL_193613">
						<span class="toplay">
							<img src="img/13-0.jpg" class="inL_452326">
						</span>
					</div>
					<div class="zizou">
						<strong> Nafisat and Rufus<br> <span>28 y.o and 35 y.o </span></strong>
						<p> We have been together for 3 years. We are living in Abuja.</p>
						<p> We reached a dead end in our sex life just over a year ago. We were well aware that if we
							continued, our relationship would not last long, so we were looking for a solution.</p>
						<p> My penis was short. It’s like only 9.8 cm long and sex did not last longer than 3 minutes. I
							consulted a sexologist, went to the gym, took pills... even tried a strange pump… Nothing
							helped.</p>
						<p> Finally, a friend recommended a try of the cream-gel he had used for a while. I researched
							the internet and found great features with impressive pre and post photos. </p>
						<p>Men said they had saved the relationship with <a href="#to_form"><b>Dragon Size</b></a>.
							It
							was always hard for me to believe in such advertising, but this time we decided to give it a
							try. I had nothing to lose.</p>
						<p>He arrived in 2 days in a simple package, which my girlfriend did not even notice</p>
						<p>I followed simple instructions, applied it every day, and I was surprised by my huge new
							disk’s size and sexual energy after 2 weeks...</p>
						<p>My girlfriend noticed it too when I fucked her. She got four orgasms at once and wanted me to
							continue to do more and more. She couldn't get enough of a huge hard cock</p>
						<p>We fuck all the time. Everywhere. For a long time. </p>
						<div class="video inL_579026">
							<span class="toplay">
								<img src="img/handjob.jpg" class="inL_482315">
							</span>
						</div>
						<h4>She wakes me up with a blowjob almost every day and begs me to fuck her! </h4>
						<p> My penis is twice as thick and 5.2 cm longer since I started using <a
								href="#to_form"><b>Dragon Size</b></a>. Now I can fuck her for an hour without stopping. I only cum when
							I sexually satisfy my girlfriend. It has only been a month and a half since I started using
							it, but I am already satisfied with my size and endurance.</p>
						<div class="clear"></div>
						<center>
							<img class="me_prod" src="img/product.png">
						</center>
						<center>
							<a class="btn" href="#to_form" target="_blank">Order Dragon Size</a>
						</center>
					</div>
				</div>
				<h1> Sexologists recommend <a href="#to_form">Dragon Size</a><br></h1>
				<strong> Doctors recommend <a href="#to_form"><b>Dragon Size</b> </a> not only to solve erection
					problems but also as a method to enlarge the penis. It is all because a small penis will never
					satisfy a woman.</strong>
				<div>
					<div class="video"><img src="img/dr-36bfd290d1.jpg"></div>
					<div class="zizou">
						<h4> Doctor Olawunmi Esan<br><span>Sexologist</span></h4>
						<p> As doctors, we recommend <a href="#to_form"><b>Dragon Size</b></a> to people who want to
							enlarge their penis and/or get rid of erectile problems.</p>
						<p><a href="#to_form"><b>Dragon Size</b></a> has nothing to do with the risks of surgery, but
							its effect in lengthening the penis and delaying ejaculation is very satisfactory.</p>
						<p>More and more often, wives or girls come to see me for consultations. They are not satisfied
							with their sex life but do not want to look for another husband. In such cases, I recommend
							Dragon Size, and they come back with their husbands to say thank you very often.</p>
						<p><a href="#to_form"><b>Dragon Size</b></a> increases the size of the penis by an average of
							3.1 - 4.2 cm, and I have personally verified its effectiveness thanks to my customers who
							become more confident. </p>
						<p><strong><i>Mixing 3 ancient herbs has an incredible effect on your erection</i></strong></p>
						<p>We don’t talk about strange new medicines made in the laboratory (such as Viagra).</p>
						<p>We talk about plants that have been used for thousands of years for various reasons. The main
							breakthrough here is that <a href="#to_form"><b>Dragon Size</b></a> has combined the
							incredible power of three herbs that are effective for your erection.</p>
						<p><strong>What is the best part?</strong></p>
						<p><u>No undesirable side effects!</u></p>
						<p>You only get what you and she want!</p>
						<ul>
							<p>Become a man who has been having sex for hours due to an incredibly powerful and
								long-lasting erection! Dragon Size stimulates blood flow to the penis and creates a
								steel erection. Enjoy sex and satisfy your woman or even a few girls!  Light up her pure
								passion and make her admire you the way you deserve it.</p>
						</ul>
						<div class="form" id="form">
							<h1>Order Dragon Size</h1>

							<div class="form_wrapper">
								<div class="form_product">
									<img src="img/product.png" alt="">
								</div>
								<div class="sec-one-form" id="sec-one-form">
									<div class="sec-one-form__discount text-center">
										<p style=" display:inline" class="wv_discount">-50%</p> OFF
									</div>
									<div class="sec-one-form__timer text-center">

										<p class="timer-end"><b>Hurry Up!</b><b style=" color:#f10101"> Only <span
													class="count_products">57</span> packs left!</b></p>
										<div class="countdown-container" id="countdown-container">
										</div>

									</div>

									<div class="sec-one__prices text-center">
										<span class="price-old wv_old-price x_currency_old">{OLD_PRICE}</span>
										<span class="price-new wv_new-price x_currency">{PRICE}</span>
									</div>

									<form name="myForm" action="" method="POST" class="wv_order-form form_order">
										<div class="form-group target_list_wrap">
											<select name="target_geo_hash" id="city"
												class=" wv_phone form-control js-select"
												style="-webkit-appearance: none !important;"></select>
										</div>

										<div class="form-group">
											<label for="name"></label>
											<input id="name" name="client" type="text" class="wv_name form-control"
												placeholder="Name" required="">
										</div>

										<div class="form-group">
											<label for="phone"></label>
											<input id="phone" name="phone" type="text"
												class=" wv_phone form-control phone_mask" placeholder="Phone number:"
												required="">
										</div>
										<div class="form-group">
											<button class="btn-buy" type="submit">BUY NOW!</button>
										</div>
									</form>
								</div>
							</div>

						</div>
					</div>
				</div>
				<h2 class="women-like">WOMEN LOVE MEN WITH PENIS LIKE PORN STARS</h2>
				<p> Photos and videos presented in this blog are displayed with the consent of the sides. Their photos
					may not be used on other web pages.</p>
				<div class="inL_209976">
					<div class="zizou1">
						<p class="inL_97168"> <img src="img/22plus-1761b7df80.jpg" class="inL_713863">
							<strong>Abaeze</strong> <br>I have been using <a href="#to_form"><b>Dragon Size</b></a>
							for
							three months now. By the end of the second month, my penis had grown by 5,4 cm. It is 18.6
							cm long and I can make love for half an hour without ejaculation now. </p>
						<p class="inL_68111"> <img src="img/olivierplus-ca29a77264.jpg" class="inL_788091">
							<strong>Chibuzor</strong> <br>I have been using <a href="#to_form"><b>Dragon Size</b></a>
							for a month now. My doctor recommended it to me because I was feeling complex about the size
							of my penis. But it has already grown by a few centimeters, it is also thicker, and the
							erections are much harder. I completely forgot about my complexes! </p>
					</div>
				</div>
				<div class="vpouste">
					<!--                    <strong style="font-size: 20px; text-transform:none;"><br/></strong>-->
					<h2>ATTENTION!</h2>
					<p>We have received thousands of letters from men who want to buy <a href="#to_form"><b>Dragon Size</b></a>.<br> We had to contact a distributor and ask for a special discount. They
						agreed to give our readers a <strong>favourable discount. Time is limited</strong>! </p>
					<a class="#to_form" href="#to_form"> </a>
					<b>
					</b>
					<center>
						<a href="#to_form" rel="nofollow" target="_blank">favourable discount. Time is limited!.</a>
					</center>
				</div>
				<div class="flex-column inL_776887">
					<h1>Read more reviews about <b class="nowrap">Dragon Size</b></h1>
					<div class="video"><img src="img/vip-1e7d63adc6.jpg" class="inL_787468"></div>
					<div class="zizou1">
						<p>Ganiru: I don't regret trying <a href="#to_form"><b>Dragon Size</b></a>. My wife is very
							happy about the result. Sex is now three times longer than in the last year. Our
							relationship has become more fulfilling. And by the way, I have gained self-confidence.</p>
						<p> I have already used up the third tube. I will not hesitate to order again after using my 6.
							Although doctors say that the effect is long-lasting even after I stop using it. I will
							write here again later to share with you if this is true.</p>
					</div>
				</div>
				<h2>A GIANT PORN STAR'S PENIS!</h2>
				<p>Umukoro wrote a comment about using <a href="#to_form"><b>Dragon Size</b></a>. </p>
				<div class="inL_609038">
					<div class="res inL_380943">
						<img src="img/mathieuplus-1669647536.jpg">
					</div>
					<div class="zizou1">
						<p>My penis was not very small, but when a friend told me about <a href="#to_form"><b>Dragon Size</b></a> cream-gel, I wanted to try it. The result: my penis became huge! But
							the most important thing is that I can make love for hours! What more could I wish for? </p>
					</div>
				</div>
				<h2>WOMEN ARE FOLLOWING ME BECAUSE OF MY PENIS SIZE </h2>
				<p>Ikemba wrote a comment about using <a href="#to_form">Dragon Size</a>. </p>
				<div class="flex-column inL_449938">
					<div class="zizou2">
						<p> I was a shy and silent man, still a virgin at 21. I was ugly and the girls didn't even look
							at me, so I never dared to come near them. My life has completely changed since I started
							using <a href="#to_form"><b>Dragon Size</b></a>.</p>
						<p> I realized that how you look is not important. Only your dick’s size is counts. I got my
							first results in just one month. My penis became huge in just three months. All the girls
							noticed it! I did not think they noticed such things. The biggest penis was the most
							important thing for them. </p>
					</div>
					<div class="zizou3">
						<p>It all started when I spent an incredible night with a girl in a German language course. 
							Then everything started to spiral. Like men, women also share their sexual experiences.
							Since the day, all the college girls have been fantasizing about the size of my penis.  I am
							enjoying the unforgettable night now. If someone had told me this a few months ago, I would
							never have believed it.</p>
					</div>
				</div>





				<div class="form_wrapper" id="to_form">
					<div class="form_product">
						<img src="img/product.png" alt="">
					</div>
					<div class="sec-one-form" id="sec-one-form">
						<div class="sec-one-form__discount text-center">
							<p style=" display:inline" class="wv_discount">-50%</p> OFF
						</div>
						<div class="sec-one-form__timer text-center">

							<p class="timer-end"><b>Hurry Up!</b><b style=" color:#f10101"> Only <span
										class="count_products">57</span> packs left!</b></p>
							<div class="countdown-container" id="countdown-container">
							</div>

						</div>

						<div class="sec-one__prices text-center">
							<span class="price-old wv_old-price x_currency_old">{OLD_PRICE}</span>
							<span class="price-new wv_new-price x_currency">{PRICE}</span>
						</div>

						<form name="myForm" action="" method="POST" class="wv_order-form form_order">
							<div class="form-group target_list_wrap">
								<select name="target_geo_hash" id="city" class=" wv_phone form-control js-select"
									style="-webkit-appearance: none !important;"></select>
							</div>

							<div class="form-group">
								<label for="name2"></label>
								<input id="name2" name="client" type="text" class="wv_name form-control"
									placeholder="Name" required="">
							</div>

							<div class="form-group">
								<label for="phone2"></label>
								<input id="phone2" name="phone" type="text" class=" wv_phone form-control phone_mask"
									placeholder="Phone number:" required="">
							</div>
							<div class="form-group">
								<button class="btn-buy" type="submit">BUY NOW!</button>
							</div>
						</form>
					</div>
				</div>




			</div>
			<div class="contenulu inL_223601">
				<p>Our editors talked to sexologists and surgeons who specialize in penis enlargement. They confirmed
					the incredible impact of <a href="#to_form"><b>Dragon Size</b></a> on penis enlargement and
					sexuality. </p><a href="#to_form"><img src="img/regisplus-2ac596d0b3.jpg"></a><strong>
					Adebayo</strong>
				<p>I ordered <a href="#to_form"><b>Dragon Size</b></a> on their website and it was delivered to the
					office 3 days later. The package was completely invisible, my colleagues did not suspect anything. I
					used the product for 3 months and stopped it 2 months ago; now I have a huge penis and lots of sex
					every day.
				</p>
				<a class="btn" href="#to_form" target="_blank">Order Dragon Size</a>
				<a href="#to_form" rel="nofollow" target="_blank"><img src="img/rolandplus-61d381748e.jpg"></a>
				<strong>Bimbo Ibrahim</strong>
				<p> I always had a tiny penis. It was a disgrace to my life. Now I have a big size. My wife is delighted
					and so am I. I will never get tired of thanking <a href="#to_form"><b>Dragon Size</b></a> for
					changing my life. </p>
				<a href="#to_form"><img src="img/sebplus-f8bdac299d.jpg"></a><strong>Mohammed Keita</strong>
				<p> When I was living in the UK and I found out about <a href="#to_form"><b>Dragon Size</b></a>, it's
					very famous there! I am glad that it is now produced and sold in my country, I can order it directly
					and the shipping costs are nice.</p>
				<a href="#to_form"><img src="img/nicolasplus-65865cf24d.jpg"></a><strong>Adelomo Usman</strong>
				<p> I think the picture speaks for itself... I am so proud of my cock, thank you, <a
						href="#to_form"><b>Dragon Size</b></a>!</p>
				<a href="#to_form"><img src="img/guillaumeplus-a587b84973.jpg"></a><strong> Tobi Sami </strong>
				<p> The little cock has been embarrassing and disappointing me for years. I felt like a nobody. My
					confusion was endless. A friend advised me to try <a href="#to_form"><b>Dragon Size</b></a>. The
					best solution ever! My penis is huge, so I can fuck for hours. Women don't stop harassing me for a
					fleeting affair. They crave my huge penis!</p>
				<a href="#to_form"><img src="img/marcos.jpg"></a><strong> Maseso Muhammad </strong>
				<p> My penis increased by 3.8 cm in 4 months of use of <a href="#to_form"><b>Dragon Size</b></a>.
					It is huge! But <a href="#to_form"><b>Dragon Size</b></a> had another completely unexpected
					effect
					on me, I gained such confidence that I became a real magnet for girls. They didn't even notice me
					before, but they all want me now! They are never disappointed.  My friends ask me what has changed,
					but it's out of the question - I won't tell them my secret.</p>
				<a href="#to_form"><img src="img/13.jpg">
				</a>
			</div>


			<div class="yorumlar">
				<div class="vplique">Recent comments </div>
				<div class="fessebouc">
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/avatar-b48c97e17a.png"></a></div>
						<div class="facezizou inL_314191">
							<p>Musa Musa </p><span>Previously my penis was 10.7 cm and I was afraid to approach a girl
								or suggest sex. My penis reached 15.6 cm in just two months. Now I can confidently
								approach any girl. <br></span>
							<img src="img/maxime-ffe569f6ab.jpg">
							<strong> <span> <a href="#to_form">Like </a> </span> <span> <a href="#to_form"
										class="nowrap">Add
										a comment</a> </span>
								<span class="date-17">
									<script type="text/javascript">
										dtime_nums(-15, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook">
							<a href="#to_form"><img src="img/avatar-b48c97e17a.png"></a>
						</div>
						<div class="facezizou inL_125138">
							<p> Umar A. </p><span>I have been married for 5 years and this is the first time I have seen
								my wife enjoying sex. I am proud to be able to make her moan with pleasure now, because
								before <a href="#to_form"><b>Dragon Size</b></a>, a sex was over in a few
								minutes.<br></span><img src="img/martin-c829573d41.jpg">
							<strong> <span> <a href="#to_form">Like </a> </span> <span> <a href="#to_form"
										class="nowrap">Add
										a comment</a> </span> <span class="date-17">
									<script type="text/javascript">
										dtime_nums(-15, true)
									</script>
								</span> </strong>
						</div>
					</div>
					<div class="lavalse comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/camille-173f0dba96.jpg"></a></div>
						<div class="facezizou inL_860230">
							<p> Aliyu K.</p><span>I haven't had an orgasm in years. Your comments give me the
								goosebumps. They have convinced me so much that I will buy a product for my husband.
								Thank you very much for your recommendation. </span>
							<strong><span> <a href="#to_form">Like </a> </span> <span> <a href="#to_form"
										class="nowrap">Add a
										comment</a> </span> <span class="date-16">
									<script type="text/javascript">
										dtime_nums(-14, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/av-pat-80bfab26d6.jpg"></a></div>
						<div class="facezizou inL_465049">
							<p> Bella :) </p><span>We bought this product because my husband ejaculated early. The
								problem disappeared a few days later. His penis grew considerably in a
								month.<br></span><img src="img/patricia-f36e794f37.png"><strong><span> <a
										href="#to_form">Like </a> </span> <span> <a href="#to_form" class="nowrap">Add a
										comment</a> </span>
								<span class="date-15">
									<script type="text/javascript">
										dtime_nums(-13, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/avatar-b48c97e17a.png"></a></div>
						<div class="facezizou inL_910953">
							<p>Lawal</p><span>It has been 3 months since I started using this cream gel. My penis has
								grown by 4.5 cm and got thicker. I can fuck 20-30 minutes before ejaculation. Now all
								the girls are talking about me. Even strangers call me. <a href="#to_form"><b>Dragon Size</b></a> has made a revolution in my sex life.</span>
							<img src="img/damien-deaf61bdc7.jpg">
							<strong><span> <a href="#to_form">Like </a> </span> <span> <a href="#to_form"
										class="nowrap">Add a
										comment</a> </span><span class="date-14">
									<script type="text/javascript">
										dtime_nums(-12, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/avatar-b48c97e17a.png"></a></div>
						<div class="facezizou inL_266261">
							<p> Idris</p><span>I bought this product to make my penis bigger, but in the end it relieved
								me of all my sexual problems. I no longer have sexual dysfunction or premature
								ejaculation. My penis has added 2.7 cm. This is amazing!</span><strong><span> <a
										href="#to_form">Like </a> </span><span> <a href="#to_form" class="nowrap">Add a
										comment</a> </span>
								<span class="date-13">
									<script type="text/javascript">
										dtime_nums(-11, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/marie-dcfabfffb2.jpg"></a></div>
						<div class="facezizou inL_995626">
							<p> Adesina </p><span>I ordered this product for my boyfriend. Last year our sex life was
								not very interesting. After only one week of use, we started making love again, like on
								our first night together. If you have problems in bed, do not miss the chance to order
								this product. </span><strong><span>
									<a href="#to_form">Like </a> </span><span> <a href="#to_form" class="nowrap">Add a
										comment</a> </span><span class="date-12">
									<script type="text/javascript">
										dtime_nums(-10, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/avatar-b48c97e17a.png"></a></div>
						<div class="facezizou inL_587688">
							<p> Ali </p><span>The size of my penis has been bothering me for years. I regret all those
								years spent in depression because of it. <a href="#to_form"><b>Dragon Size</b></a>
								Ali

								The size of my penis has been bothering me for years. I regret all those years spent in
								depression because of it. Dragon Size solved my problems in 2 months and now my penis
								size is 19.2 cm :) </span><img src="img/boris-456f74843d.jpg"><strong><span> <a
										href="#to_form">Like
									</a> </span>
								<span> <a href="#to_form" class="nowrap">Add a comment</a> </span>
								<span class="date-11">
									<script type="text/javascript">
										dtime_nums(-9, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/gregav-67110a33e9.jpg"></a></div>
						<div class="facezizou inL_593020">
							<p>Eze </p><span>It is difficult for my wife to take my dick in her mouth now. You can see
								it for yourself. I didn't think he could grow up so much <br></span><img
								src="img/greg-1dff7fe182.jpg"><strong><span> <a href="#to_form">Like </a> </span>
								<span> <a href="#to_form" class="nowrap">Add a comment</a> </span>
								<span class="date-10">
									<script type="text/javascript">
										dtime_nums(-8, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="lavalse comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/emilie-3e05a4257b.jpg"></a></div>
						<div class="facezizou inL_378848">
							<p> Jaja </p><span> Some women are lucky... I envy them. This is a great achievement... In
								length and thickness. </span><strong><span> <a href="#to_form">Like </a> </span><span>
									<a href="#to_form" class="nowrap">Add a comment</a> </span>
								<span class="date-9">
									<script type="text/javascript">
										dtime_nums(-7, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/guillaumeav-50b114c75d.jpg"></a></div>
						<div class="facezizou inL_232050">
							<p>Nwankwo </p><span>My penis is bigger now, and I can decide when to finish. I feel like I
								have become a sex god.</span><strong><span> <a href="#to_form">Like </a>
								</span><span> <a href="#to_form" class="nowrap">Add a comment</a> </span>
								<span class="date-8">
									<script type="text/javascript">
										dtime_nums(-6, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/6-0c432c4fe9.jpg"></a></div>
						<div class="facezizou inL_79123">
							<p> Bankole</p><span>This product actually saved my marriage. My penis is much bigger now,
								and my wife really likes it. ;) </span><strong><span> <a href="#to_form">Like
									</a> </span> <span> <a href="#to_form" class="nowrap">Add a comment</a> </span>
								<span class="date-7">
									<script type="text/javascript">
										dtime_nums(-5, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="lavalse comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/virginie-769ad0d7f6.jpg"></a></div>
						<div class="facezizou inL_202286">
							<p> Zaza </p><span>Unbelievable! Does it also prevent premature ejaculation? My husband
								suffers from this, so I will think about buying this product. We would be very happy if
								you' ll answer. </span><strong><span> <a href="#to_form">Like </a> </span> <span> <a
										href="#to_form" class="nowrap">Add a comment</a> </span>
								<span class="date-6">
									<script type="text/javascript">
										dtime_nums(-4, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="lavalse comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/6-0c432c4fe9.jpg"></a></div>
						<div class="facezizou inL_547243">
							<p> Gbeho K. </p><span>Yes Masha, I used to come within 5 minutes. I never finished with <a
									href="#to_form"><b>Dragon Size</b></a> before 20 minutes later. And my wife
								finally
								has real orgasms.</span><strong><span> <a href="#to_form">Like </a>
								</span> <span> <a href="#to_form" class="nowrap">Add a comment</a> </span>
								<span class="date-5">
									<script type="text/javascript">
										dtime_nums(-3, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/avatar-b48c97e17a.png"></a></div>
						<div class="facezizou inL_516726">
							<p> Noname .</p><span>Thank you, <a href="#to_form"><b>Dragon Size</b></a>. You saved my
								marriage! In addition to my small penis, I had no erection for 3 years. It is now a
								normal size and I come whenever I want. If anyone here is wondering if they should buy
								this product, don't hesitate. This saved my marriage and I recommend it to everyone.<img
									src="img/pierre-6319d08a9f.jpg"></span><strong><span>
									<a href="#to_form">Like </a> </span> <span> <a href="#to_form" class="nowrap">Add a
										comment</a> </span>
								<span class="date-4">
									<script type="text/javascript">
										dtime_nums(-2, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/avatar-b48c97e17a.png"></a></div>
						<div class="facezizou inL_181276">
							<p> The sex god </p><span>No comments. I will show you the photo, and you decide. I started
								using it a month ago and my penis is 4.3 cm longer.<br></span><img
								src="img/eric-5deb66c956.jpg"><strong><span> <a href="#to_form">Like </a> </span><span>
									<a href="#to_form" class="nowrap">Add a comment</a> </span>
								<span class="date-3">
									<script type="text/javascript">
										dtime_nums(-1, true)
									</script>
								</span></strong>
						</div>
					</div>
					<div class="dismoi comment">
						<div class="fessedebook"><a href="#to_form"><img src="img/7-e1c78db5f5.jpg"></a></div>
						<div class="facezizou inL_604762">
							<p> Nega Nega </p><span>I received <a href="#to_form"><b>Dragon Size</b></a> a month ago,
								and now that I have discovered this blog, I took advantage of the discount to buy for
								another 2 months. My penis grew by 3.6 cm. This is really amazing.</span><strong><span>
									<a href="#to_form">Like </a> </span> <span> <a href="#to_form" class="nowrap">Add a
										comment</a> </span>
								<span class="date-2">
									<script type="text/javascript">
										dtime_nums(0, true)
									</script>
								</span></strong>
						</div>
					</div>
					<center>
						<a class="btn" href="#to_form" target="_blank">Order Dragon Size</a>
					</center>
				</div>
			</div>
		</div>
	</div>


	<div class="ac_footer">
		<a href="{TERMS_URL}" target="_blank">Terms &amp; Conditions </a> |
		<a href="{PRIVACY_POLICY_URL}" target="_blank">Privacy Policy</a> |
		<a target="blank" target="_blank" href="{RETURNS_URL}">Returns, Refunds and Exchanges Policy</a>
	</div>

	<script>
		$(function () {
			$('a[href^="#"]').on('click', function (event) {
				// отменяем стандартное действие
				event.preventDefault();

				var sc = $(this).attr("href"),
					dn = $(sc).offset().top;
				/*
				 * sc - в переменную заносим информацию о том, к какому блоку надо перейти
				 * dn - определяем положение блока на странице
				 */

				$('html, body').animate({
					scrollTop: dn
				}, 1000);

				/*
				 * 1000 скорость перехода в миллисекундах
				 */
			});
		});
	</script>
</body>

</html>